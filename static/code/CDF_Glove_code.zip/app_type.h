#ifndef __APP_TYPE_H
#define __APP_TYPE_H

#define  ADC1_BUFFER_SIZE 5
#define  ADC2_BUFFER_SIZE 5
#define  ADC3_BUFFER_SIZE 6
#define MAX_MOTOR_NUM 5  
#define MOTOR_BUFFER_SIZE 4 
#endif // __APP_TYPE_H
