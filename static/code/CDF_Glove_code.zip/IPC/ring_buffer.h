#ifndef __RING_BUFFER_H
#define __RING_BUFFER_H

#include <stdint.h>
#include <stdbool.h>
#include "cmsis_os.h"

#define USE_MUTEX 1


typedef enum {
    RING_BUFFER_OK = 0,
    RING_BUFFER_FULL,
    RING_BUFFER_EMPTY,
    RING_BUFFER_ERROR
} RingBufferStatus_t;

typedef struct {
    uint8_t *buffer;           
    uint32_t size;            
    uint32_t element_size;    
    volatile uint32_t write_index; 
    volatile uint32_t read_index;  
#if USE_MUTEX
    osMutexId mutex;  
#endif
} RingBuffer_t;

RingBufferStatus_t RingBuffer_Init(RingBuffer_t *rb, void *buffer, uint32_t size, uint32_t element_size);

RingBufferStatus_t RingBuffer_Write(RingBuffer_t *rb, const void *data);
RingBufferStatus_t RingBuffer_WriteWithLength(RingBuffer_t *rb, const void *data, uint32_t length);

RingBufferStatus_t RingBuffer_Read(RingBuffer_t *rb, void *data);
RingBufferStatus_t RingBuffer_ReadWithLength(RingBuffer_t *rb, void *data, uint32_t *length);

uint32_t RingBuffer_GetCount(const RingBuffer_t *rb);

bool RingBuffer_IsEmpty(const RingBuffer_t *rb);

bool RingBuffer_IsFull(const RingBuffer_t *rb);

void RingBuffer_Clear(RingBuffer_t *rb);

#endif // __RING_BUFFER_H
