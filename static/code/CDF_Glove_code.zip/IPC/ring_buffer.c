
#include "ring_buffer.h"
#include "logger/logger.h"
#include <string.h>

#if USE_MUTEX
osMutexDef(rb_mutex);
#endif

RingBufferStatus_t RingBuffer_Init(RingBuffer_t *rb, void *buffer, uint32_t size, uint32_t element_size)
{
    if (!rb || !buffer || !size || !element_size) {
        LOG_ERROR("RingBuffer_Init FAILED: rb=%p, buffer=%p, size=%d, element_size=%d\r\n", rb, buffer, size, element_size);
        return RING_BUFFER_ERROR;
    }
    
    rb->buffer = buffer;
    rb->size = size;
    rb->element_size = element_size;
    rb->write_index = 0;
    rb->read_index = 0;

#if USE_MUTEX
    rb->mutex = osMutexCreate(osMutex(rb_mutex));
    if (!rb->mutex) {
        LOG_ERROR("RingBuffer_Init: osMutexCreate failed.\r\n");
        return RING_BUFFER_ERROR; 
    }
#endif
    
    return RING_BUFFER_OK;
}

RingBufferStatus_t RingBuffer_Write(RingBuffer_t *rb, const void *data)
{
    if (!rb || !data) {
        return RING_BUFFER_ERROR;
    }

    RingBufferStatus_t status = RING_BUFFER_ERROR;
#if USE_MUTEX
    if (osMutexWait(rb->mutex, osWaitForever) == osOK) {
#endif
        uint32_t next_write = (rb->write_index + 1) % rb->size;
    
        if (next_write == rb->read_index) {
            // return RING_BUFFER_FULL;
            rb->read_index = (rb->read_index + 1) % rb->size; // overwrite the oldest element
        }
        
        uint8_t *write_ptr = rb->buffer + (rb->write_index * rb->element_size);
        memcpy(write_ptr, data, rb->element_size);
        rb->write_index = next_write;

        status = RING_BUFFER_OK;
#if USE_MUTEX
        osMutexRelease(rb->mutex);
    }
#endif
    
    return status;
}

RingBufferStatus_t RingBuffer_WriteWithLength(RingBuffer_t *rb, const void *data, uint32_t length)
{
    if (!rb || !data || length > rb->element_size) {
        LOG_ERROR("RingBuffer_WriteWithLength: rb=%p, length=%d, rb->element_size=%d\r\n", rb, length, rb->element_size);
        return RING_BUFFER_ERROR;
    }

    RingBufferStatus_t status = RING_BUFFER_ERROR;
#if USE_MUTEX
    if (osMutexWait(rb->mutex, osWaitForever) == osOK) {
#endif
        uint32_t next_write = (rb->write_index + 1) % rb->size;
        
        if (next_write == rb->read_index) {
            // return RING_BUFFER_FULL;
            rb->read_index = (rb->read_index + 1) % rb->size; // overwrite the oldest element
        }
        
        uint8_t *write_ptr = rb->buffer + (rb->write_index * rb->element_size);
        *(uint32_t*)write_ptr = length;
        memcpy(write_ptr + sizeof(uint32_t), data, length);
        rb->write_index = next_write;

        status = RING_BUFFER_OK;
#if USE_MUTEX
        osMutexRelease(rb->mutex);

        // LOG_INFO("RingBuffer_WriteWithLength: rb->read_index=%d, rb->write_index=%d\r\n", rb->read_index, rb->write_index);
    }
#endif
    return status;
}

RingBufferStatus_t RingBuffer_Read(RingBuffer_t *rb, void *data)
{
    if (!rb || !data) {
        return RING_BUFFER_ERROR;
    }

    RingBufferStatus_t status = RING_BUFFER_ERROR;
#if USE_MUTEX
    if (osMutexWait(rb->mutex, osWaitForever) == osOK) {
#endif
        if (rb->read_index == rb->write_index) {
            status = RING_BUFFER_EMPTY;
        } else {
            uint8_t *read_ptr = rb->buffer + (rb->read_index * rb->element_size);
            memcpy(data, read_ptr, rb->element_size);
            rb->read_index = (rb->read_index + 1) % rb->size;
            status = RING_BUFFER_OK;
        }
#if USE_MUTEX
        osMutexRelease(rb->mutex);
    }
#endif        
    
    return status;
}

RingBufferStatus_t RingBuffer_ReadWithLength(RingBuffer_t *rb, void *data, uint32_t *length)
{
    if (!rb || !data || !length) {
        LOG_ERROR("RingBuffer_ReadWithLength FAIL: rb=%p, length=%p\r\n", rb, length);
        return RING_BUFFER_ERROR;
    }

    RingBufferStatus_t status = RING_BUFFER_ERROR;
#if USE_MUTEX
    if (osMutexWait(rb->mutex, osWaitForever) == osOK) {
#endif    
        if (rb->read_index == rb->write_index) {
            status = RING_BUFFER_EMPTY;
        } else {
            uint8_t *read_ptr = rb->buffer + (rb->read_index * rb->element_size);
            *length = *(uint32_t*)read_ptr;
            if (*length > rb->element_size - sizeof(uint32_t)) {
                return RING_BUFFER_ERROR;
            }
            memcpy(data, read_ptr + sizeof(uint32_t), *length);
            rb->read_index = (rb->read_index + 1) % rb->size;
            status = RING_BUFFER_OK;
        }
#if USE_MUTEX
        osMutexRelease(rb->mutex);
    }
#endif  
    
    return status;
}

uint32_t RingBuffer_GetCount(const RingBuffer_t *rb)
{
    if (!rb) {
        return 0;
    }
    
    if (rb->write_index >= rb->read_index) {
        return rb->write_index - rb->read_index;
    } else {
        return rb->size - (rb->read_index - rb->write_index);
    }
}

bool RingBuffer_IsEmpty(const RingBuffer_t *rb)
{
    return rb && (rb->read_index == rb->write_index);
}

bool RingBuffer_IsFull(const RingBuffer_t *rb)
{
    if (!rb) {
        return false;
    }
    return ((rb->write_index + 1) % rb->size) == rb->read_index;
}

void RingBuffer_Clear(RingBuffer_t *rb)
{
    if (rb) {
        rb->write_index = rb->read_index = 0;
    }
}
