#ifndef __D_BUFFER_H__
#define __D_BUFFER_H__

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

typedef struct {
    void *buffers[2];
    uint32_t element_size;
    uint32_t buffer_size;
    volatile uint32_t write_index;
    volatile uint32_t read_index;
} DoubleBuffer_t;

typedef enum {
    DOUBLE_BUFFER_OK = 0,
    DOUBLE_BUFFER_ERROR
} DoubleBufferStatus_t;

DoubleBufferStatus_t DoubleBuffer_Init(DoubleBuffer_t *db, 
                                       void *buffer1, void *buffer2,
                                       uint32_t buffer_size, 
                                       uint32_t element_size);
void* DoubleBuffer_GetWriteBuffer(DoubleBuffer_t *db);
const void* DoubleBuffer_GetReadBuffer(DoubleBuffer_t *db);
void DoubleBuffer_SwapBuffers(DoubleBuffer_t *db);

#endif
