#include "d_buffer.h"

DoubleBufferStatus_t DoubleBuffer_Init(DoubleBuffer_t *db, void *buffer1, void *buffer2, 
                                     uint32_t buffer_size, uint32_t element_size)
{
    if (!db || !buffer1 || !buffer2 || !buffer_size || !element_size) {
        return DOUBLE_BUFFER_ERROR;
    }
    
    db->buffers[0] = buffer1;
    db->buffers[1] = buffer2;
    db->buffer_size = buffer_size;
    db->element_size = element_size;
    db->write_index = 0;
    db->read_index = 1;
    
    return DOUBLE_BUFFER_OK;
}

void* DoubleBuffer_GetWriteBuffer(DoubleBuffer_t *db)
{
    return db ? db->buffers[db->write_index] : NULL;
}

const void* DoubleBuffer_GetReadBuffer(DoubleBuffer_t *db)
{
    return db ? db->buffers[db->read_index] : NULL;
}

void DoubleBuffer_SwapBuffers(DoubleBuffer_t *db)
{
    if (db) {
        uint32_t temp = db->write_index;
        db->write_index = db->read_index;
        db->read_index = temp;
    }
}
