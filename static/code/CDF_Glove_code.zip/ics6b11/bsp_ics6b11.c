#include "bsp_ics6b11.h"
//#include "delay.h"
#include <stdio.h>
//#include "log.h"
//#include "rtt_log.h"
#include "main.h"
#include "i2c.h"
#include "memorymap.h"
#include "usart.h"
#include "gpio.h"
#include "stm32h7xx_hal.h"
#define check_error_return 
#define usleep_range(x, y) systick_delay_us(y)
#define ics_err log_error
#define ics_info log_info
#define ics_dbg log_debug

#define EFS_RETRY_TIMES         3
#define RT6010_MAX_RAM_SIZE	1536

#define MIN(x, y) ((x) < (y) ? (x) : (y))

struct RT6010_CONFIG rt6010_config =
{
    0, 0, 0, 0, 0, 0,
    {0x00,0x02,0x20,0x02,0x80,0x00,0x80,0x01}
};

LinearMotoCmd_t linearMotoPlay[LINEAR_MAX_NUM] = {0};
uint8_t stream_demo_flag = 0; 
uint32_t data_demo_index = 0; 

const int8_t ics6b11_f0_wave_data[] = {
    0,22,44,64,82,98,111,120,125,126,124,117,107,93,76,57,36,14,-7,-30,-51,-71,
    -88,-103,-114,-122,-126,-126,-122,-114,-102,-87,-70,-50,-29,-6,15,37,58,77,
    94,107,118,124,126,125,119,110,97,81,63,43,21,-1,-23,-45,-65,-83,-99,-111,
    -120,-125,-126,-123,-117,-106,-92,-75,-56,-35,-13,9,31,52,72,89,104,115,123,
    126,126,121,113,101,86,69,49,27,5,-17,-39,-60,-78,-95,-108,-118,-124,-126,
    -125,-119,-109,-97,-80,-62,-41,-19,2,25,46,66,84,100,112,121,125,126,123,116,
    105,91,74,55,34,11,-10,-32,-54,-73,-90,-105,-116,-123,-126,-126,-121,-113,
    -101,-85,-68,-47,-26,-3,18,40,61,79,96,109,119,124,127,124,119,109,96,79,61,
    40,18,-3,-26,-47,-68,-85,-101,-113,-121,-126,-126,-123,-116,-105,-90,-73,-54,-32
};

#define STREAM_DATA_LEN        sizeof(ics6b11_f0_wave_data) 

const int8_t ram_wave_data[] =
/*{
    0,0,0,0,0,0,0,1,2,3,6,12,24,47,85,106,117,122,125,126,126,124,120,112,97,
    66,5,-61,-94,-111,-120,-124,-126,-126,-126,-124,-120,-112,-96,-64,-3,34,
    26,-30,-79,-103,-116,-122,-125,-127,-127,-128,-128,-128,-128,-128,-127,
    -125,-123,-117,-106,-84,-44,-16,-2,6,9,11,12,12,13,13,13,13,13,14,15,18,
    22,22,11,6,3,1,0,0,0,0,0,0,0,0
};*/
{
	0,23,46,67,86,102,114,123,127,127,124,116,104,88,70,49,27,3,-20,-43,-64,-83,-99,-112,
	-122,-127,-128,-124,-117,-105,-91,-72,-52,-30,-7,17,40,61,81,97,111,121,126,127,125,118,
	107,93,75,55,33,10,-13,-36,-58,-78,-95,-109,-119,-126,-128,-126,-119,-109,-95,-78,-58,-36,
	-13,10,33,55,75,93,107,118,125,127,126,121,111,97,81,61,40,17,-7,-30,-52,-72,-91,-105,-117,
	-124,-128,-127,-122,-112,-99,-83,-64,-43,-20,3,27,49,70,88,104,116,124,127,127,123,114,102,
	86,67,46,23,0,-23,-46,-67,-86,-102,-114,-123,-127,-128,-124,-116,-104,-88,-70,-49,-27,-3,
	20,43,64,83,99,112,122,127,127,124,117,105,91,72,52,30,7,-17,-40,-61,-81,-97,-111,-121,-126,
	-128,-125,-118,-107,-93,-75,-55,-33,-10,13,36,58,78,95,109,119,126,127,126,119,109,95,
	78,58,36,13,-10,-33,-55,-75,-93,-107,-118,-125,-128,-126,-121,-111,-97,-81,-61,-40,-17,7,
	30,52,72,91,105,117,124,127,127,122,112,99,83,64,43,20,-3,-27,-49,-70,-88,-104,-116,-124,
	-128,-127,-123,-114,-102,-86,-67,-46,-23,0,23,46,67,86,102,114,123,127,127,124,116,104,
	88,70,49,27,3,-20,-43,-64,-83,-99,-112,-122,-127,-128,-124,-117,-105,-91,-72,-52,-30,-7,
	17,40,61,81,97,111,121,126,127,125,118,107,93,75,55,33,10,-13,-36,-58,-78,-95,-109,-119,
	-126,-128,-126,-119,-109,-95,-78,-58,-36,-13,10,33,55,75,93,107,118,125,127,126,121,111,
	97,81,61,40,17,-7,-30,-52,-72,-91,-105,-117,-124,-128,-127,-122,-112,-99,-83,-64,-43,-20

};

const int8_t wave_data[] =
{
    0,0,0,0,0,0,0,1,2,3,6,12,24,47,85,106,117,122,125,126,126,124,120,112,97,
    66,5,-61,-94,-111,-120,-124,-126,-126,-126,-124,-120,-112,-96,-64,-3,34,
    26,-30,-79,-103,-116,-122,-125,-127,-127,-128,-128,-128,-128,-128,-127,
    -125,-123,-117,-106,-84,-44,-16,-2,6,9,11,12,12,13,13,13,13,13,14,15,18,
    22,22,11,6,3,1,0,0,0,0,0,0,0,0
};
#define WAVE_DATA_LEN_RAM    sizeof(wave_data)

const uint8_t list_data[] = {1,0,1,0};

#define LIST_DATA_LEN        sizeof(list_data)
#define WAVE_DATA_LEN        sizeof(ram_wave_data)

static int32_t ics6b11_get_chip_id(struct ics_haptic_data *haptic_data);
static int32_t ics6b11_set_play_mode(struct ics_haptic_data *haptic_data, uint8_t mode_val);
static int32_t ics6b11_play_go(struct ics_haptic_data *haptic_data);
static int32_t ics6b11_play_stop(struct ics_haptic_data *haptic_data);
static int32_t ics6b11_clear_stream_fifo(struct ics_haptic_data *haptic_data, uint8_t stream_index);
static int32_t ics6b11_set_stream_data(struct ics_haptic_data *haptic_data, const uint8_t *data, uint16_t size, uint8_t stream_index);
static int32_t ics6b11_set_gain(struct ics_haptic_data *haptic_data, uint8_t gain_val);
extern int32_t ics6b11_chip_init(struct ics_haptic_data *haptic_data, I2C_HandleTypeDef *hi2c);
extern int32_t ics6b11_get_irq_state(struct ics_haptic_data *haptic_data);

void ics6b11_init_i2c(struct ics_haptic_data *haptic_data, I2C_HandleTypeDef *hi2c , uint8_t device_address) {
    haptic_data->i2c.i2c_read = i2c_read;
    haptic_data->i2c.i2c_write = i2c_write;
    haptic_data->i2c.hi2c = hi2c;
    haptic_data->i2c.device_address = device_address; 
}

static int ics6b11_efuse_read(struct ics_haptic_data *haptic_data, uint8_t index, uint8_t *data){
    uint16_t cnt = 0;
    uint8_t reg_val;

    reg_val = index;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_EFS_ADDR_INDEX, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = ICS6B1X_BIT_EFS_READ;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_EFS_MODE_CTRL, &reg_val, 1, haptic_data->i2c.hi2c);

    while(cnt < EFS_RETRY_TIMES){
//        systick_delay_us(20);
			HAL_Delay(2);
        haptic_data->i2c.i2c_read(haptic_data->i2c.device_address, ICS6B1X_REG_EFS_MODE_CTRL, &reg_val, 1, haptic_data->i2c.hi2c);
        if((reg_val & ICS6B1X_BIT_EFS_READ) == 0){
            haptic_data->i2c.i2c_read(haptic_data->i2c.device_address, ICS6B1X_REG_EFS_RD_DATA, &reg_val, 1, haptic_data->i2c.hi2c);
            *data = (uint8_t)reg_val;
            return 1;
        }
    }

    return -1;
}

static int ics6b11_apply_trim(struct ics_haptic_data *haptic_data){
    int32_t i, efs_data;
    uint8_t trim_val, *efs_data_p;
    uint8_t reg_val;
    int32_t retry = 0;

    //soft reset
    reg_val = 0x01;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_SOFT_RESET, &reg_val, 1, haptic_data->i2c.hi2c);
    do{
        haptic_data->i2c.i2c_read(haptic_data->i2c.device_address, ICS6B1X_REG_SOFT_RESET, &reg_val, 1, haptic_data->i2c.hi2c);
    }while((reg_val & 0x01) && (retry++ < 10));

    /* read out trim data from efuse */ 
    efs_data_p = (uint8_t*)&efs_data;
    for(i = 0; i < 4; ++i){
        ics6b11_efuse_read(haptic_data, i, efs_data_p + i);
    }

    uint8_t efs_ver = (efs_data & ICS6B1X_EFS_VERSION_MASK) >> ICS6B1X_EFS_VERSION_OFFSET;
//    log_print(LOG_LEVEL_INFO,"ics6b11 efs_ver = %d\r\n", efs_ver);
    /* apply trim data */
    trim_val = (efs_data & ICS6B1X_EFS_OSC_LDO_TRIM_MASK) >> ICS6B1X_EFS_OSC_LDO_TRIM_OFFSET;
    reg_val = trim_val << 6;
    trim_val = (efs_data & ICS6B1X_EFS_PMU_LDO_TRIM_MASK) >> ICS6B1X_EFS_PMU_LDO_TRIM_OFFSET;
    reg_val |= (trim_val << 4);
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_PMU_CFG3, &reg_val, 1, haptic_data->i2c.hi2c);
    trim_val = (efs_data & ICS6B1X_EFS_BIAS_1P2V_TRIM_MASK) >> ICS6B1X_EFS_BIAS_1P2V_TRIM_OFFSET;
    reg_val = trim_val << 4;
    trim_val = (efs_data & ICS6B1X_EFS_BIAS_I_TRIM_MASK) >> ICS6B1X_EFS_BIAS_I_TRIM_OFFSET;
    reg_val |= trim_val;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_PMU_CFG4, &reg_val, 1, haptic_data->i2c.hi2c);

    trim_val = (efs_data & ICS6B1X_EFS_OSC_TRIM_MASK) >> ICS6B1X_EFS_OSC_TRIM_OFFSET;
    trim_val ^= 0x80;
    reg_val = trim_val;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_OSC_CFG1, &reg_val, 1, haptic_data->i2c.hi2c);

    reg_val = 0x0F;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,0x2A, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = 0x00;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG1, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = 0x01;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);

    reg_val = 0x01;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BOOST_CFG1, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = 0x04;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BOOST_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = 0x0A;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BOOST_CFG3, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = 0x50;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BOOST_CFG4, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = 0x1C;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BOOST_CFG5, &reg_val, 1, haptic_data->i2c.hi2c);

    reg_val = 0x29;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_PA_CFG1, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = 0x03;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_PA_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);

    reg_val = 0x1C;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_PMU_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);
    
    if(efs_ver == 0x01){
        reg_val = 0x0F;
        haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,0x2A, &reg_val, 1, haptic_data->i2c.hi2c);
        reg_val = 0x00;
        haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG1, &reg_val, 1, haptic_data->i2c.hi2c);
        reg_val = 0x50;
        haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BOOST_CFG4, &reg_val, 1, haptic_data->i2c.hi2c);
    }else{
        reg_val = 0x0B;
        haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,0x2A, &reg_val, 1, haptic_data->i2c.hi2c);
        reg_val = 0x06;
        haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG1, &reg_val, 1, haptic_data->i2c.hi2c);
        reg_val = 0x58;
        haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BOOST_CFG4, &reg_val, 1, haptic_data->i2c.hi2c);
    }
    return 0;
}

static int ics6b11_private_init(struct ics_haptic_data *haptic_data){
    uint8_t reg_val;
    struct ics_haptic_chip_config *chip_config = &haptic_data->chip_config;
    int32_t retry = 0;

    //clear RAM section
    retry = 0;

    reg_val = 0x08;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_RAM_CFG, &reg_val, 1, haptic_data->i2c.hi2c);
    do{
        haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_RAM_CFG, &reg_val, 1, haptic_data->i2c.hi2c);
    }while((reg_val & 0x08) && (retry++ < 10));

    reg_val = (chip_config->gain & 0xFF);
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_GAIN_CFG, &reg_val, 1, haptic_data->i2c.hi2c);

    reg_val = (chip_config->max_bst_vol & 0xFF);
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BOOST_CFG3, &reg_val, 1, haptic_data->i2c.hi2c);

    reg_val = (chip_config->wave_base_addr & 0xFF);
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_WAVE_BASE_ADDR_L, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = ((chip_config->wave_base_addr & 0xFF00) >> 8);
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_WAVE_BASE_ADDR_H, &reg_val, 1, haptic_data->i2c.hi2c);

    reg_val = (chip_config->list_base_addr & 0xFF);
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_LIST_BASE_ADDR_L, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = ((chip_config->list_base_addr & 0xFF00)) >> 8;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_LIST_BASE_ADDR_H, &reg_val, 1, haptic_data->i2c.hi2c);

    chip_config->fifo_size = chip_config->list_base_addr;

    reg_val = (chip_config->fifo_ae & 0xFF);
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_FIFO_AE_L, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = ((chip_config->fifo_ae & 0xFF00)) >> 8;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_FIFO_AE_H, &reg_val, 1, haptic_data->i2c.hi2c);

    reg_val = (chip_config->fifo_af & 0xFF);
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_FIFO_AF_L, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = ((chip_config->fifo_af & 0xFF00)) >> 8;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_FIFO_AF_H, &reg_val, 1, haptic_data->i2c.hi2c);

    reg_val = 0x00;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_PROTECTION_MASK1, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = 0x00;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_PROTECTION_MASK2, &reg_val, 1, haptic_data->i2c.hi2c);

    reg_val = 0x00;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_INT_MASK, &reg_val, 1, haptic_data->i2c.hi2c);
    return 0;
}

int32_t ics6b11_chip_init(struct ics_haptic_data *haptic_data, I2C_HandleTypeDef *hi2c){
		
    if((haptic_data->i2c.i2c_read == NULL) || (haptic_data->i2c.i2c_write == NULL)){
		printf("i2c function not init\r\n");
        return -1;
    }
	  int32_t ret = 0;
		
	  ret = ics6b11_get_chip_id(haptic_data);

//    ics_dbg("ics6b11 chip id: 0x%04X\n", haptic_data->chip_config.chip_id);
	  printf("ics6b11 chip id: 0x%04X\r\n",haptic_data->chip_config.chip_id);
    if(haptic_data->chip_config.chip_id != ICS6B11_CHIP_ID){
		printf("chip id doesn't match! current: %02X, expected: %02X\r\n", haptic_data->chip_config.chip_id, ICS6B11_CHIP_ID);
//        ics_err("chip id doesn't match! current: %02X, expected: %02X\n", haptic_data->chip_config.chip_id, ICS6B11_CHIP_ID);
        return -1;
    }
 
    ret = ics6b11_apply_trim(haptic_data);
    if(ret < 0){
		printf("%s: Failed to apply chip trim data! ret = %d\r\n", __func__, ret);
//        ics_err("%s: Failed to apply chip trim data! ret = %d\n", __func__, ret);
        return ret;
    }

    ret = ics6b11_private_init(haptic_data);
    if(ret < 0){
		printf("%s, Failed to initialize ics6b11 private data! ret = %d\r\n", __func__, ret);
//        ics_err("%s, Failed to initialize ics6b11 private data! ret = %d\n", __func__, ret);
        return ret;
    }

    return ret;
}


static int32_t ics6b11_get_chip_id(struct ics_haptic_data *haptic_data){
    int32_t ret = 0;
    uint8_t reg_val = 0;

    ret = haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_DEV_ID, &reg_val, 1, haptic_data->i2c.hi2c);
    haptic_data->chip_config.chip_id = reg_val;

    return ret;
}

static int32_t ics6b11_get_reg(struct ics_haptic_data *haptic_data, uint8_t reg_addr, uint8_t *reg_data){
    int32_t ret = 0;
    ret = haptic_data->i2c.i2c_read(haptic_data->i2c.device_address, reg_addr, reg_data, 1, haptic_data->i2c.hi2c);

    return ret;
}

static int32_t ics6b11_set_reg(struct ics_haptic_data *haptic_data, uint8_t reg_addr, uint8_t reg_data){
    int32_t ret = 0;

    ret = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, reg_addr, &reg_data, 1, haptic_data->i2c.hi2c);

    return ret;
}

int32_t ics6b11_get_f0(struct ics_haptic_data *haptic_data){
    uint8_t reg_val;
    uint8_t reg_val1, reg_val2;
    uint16_t czVal1 = 0, czVal2 = 0, czVal3 = 0, czVal4 = 0, czVal5 = 0;
		int32_t get_fo_zhi = 0;
		
    // Enable F0 Detection
    // F0 = 192000 / 2133 = 90HZ
//    reg_val = 0x55;
	    reg_val = 0x69;

    get_fo_zhi=haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_LRA_F0_CFG1, &reg_val, 1, haptic_data->i2c.hi2c);
//		    printf("get_fo_zhi_1=%d\r\n",get_fo_zhi);

//    reg_val = 0x08;
	    reg_val = 0x04;

    get_fo_zhi=haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_LRA_F0_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);
//				printf("get_fo_zhi_2=%d\r\n",get_fo_zhi);

    reg_val = 0x26;
    get_fo_zhi=haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG3, &reg_val, 1, haptic_data->i2c.hi2c);
//				printf("get_fo_zhi_3=%d\r\n",get_fo_zhi);

    reg_val = 0x20;
    get_fo_zhi=haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG4, &reg_val, 1, haptic_data->i2c.hi2c);
//				printf("get_fo_zhi_4=%d\r\n",get_fo_zhi);

    reg_val = 0x01;
    get_fo_zhi=haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_DETECT_FO_CFG, &reg_val, 1, haptic_data->i2c.hi2c);
//				printf("get_fo_zhi_5=%d\r\n",get_fo_zhi);

//#endif
    // Play and wait for play done!
    ics6b11_play_stop(haptic_data);
    ics6b11_clear_stream_fifo(haptic_data, 1);
		ics6b11_set_gain(haptic_data, 0x64); //0x23

//    ics6b11_set_play_mode(haptic_data, ICS6B11_RICHTAP_STREAM_MODE);
    ics6b11_set_play_mode(haptic_data, ICS6B11_PLAY_STREAM_MODE);
    ics6b11_play_go(haptic_data);
    ics6b11_set_stream_data(haptic_data, (uint8_t *)ics6b11_f0_wave_data, sizeof(ics6b11_f0_wave_data), 1);
//    usleep_range(30000, 35000);
		HAL_Delay(35);
#ifdef DEBUG
    // Calculate F0
    get_fo_zhi=haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CZ1_VAL1, &reg_val1, 1, haptic_data->i2c.hi2c);
			printf("get_fo_zhi_6=%d\r\n",get_fo_zhi);

    get_fo_zhi=haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CZ1_VAL2, &reg_val2, 1, haptic_data->i2c.hi2c);
			printf("get_fo_zhi_7=%d\r\n",get_fo_zhi);

    int32_t a = reg_val1;
			printf("ICS6B1X_REG_BEMF_CZ1_VAL1 = %d\r\n", a);

    int32_t bb = reg_val2;
			printf("ICS6B1X_REG_BEMF_CZ1_VAL2 = %d\r\n", bb);

		
    czVal1 = (uint16_t)(reg_val2 & 0x3F);
    czVal1 = (uint16_t)((czVal1 << 8) | reg_val1);

    get_fo_zhi=haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CZ2_VAL1, &reg_val1, 1, haptic_data->i2c.hi2c);
										printf("get_fo_zhi_8=%d\r\n",get_fo_zhi);

    get_fo_zhi=haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CZ2_VAL2, &reg_val2, 1, haptic_data->i2c.hi2c);
										printf("get_fo_zhi_9=%d\r\n",get_fo_zhi);

    czVal2 = (uint16_t)(reg_val2 & 0x3F);
    czVal2 = (uint16_t)((czVal2 << 8) | reg_val1);

    get_fo_zhi=haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CZ3_VAL1, &reg_val1, 1, haptic_data->i2c.hi2c);
												printf("get_fo_zhi_10=%d\r\n",get_fo_zhi);

    get_fo_zhi=haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CZ3_VAL2, &reg_val2, 1, haptic_data->i2c.hi2c);
												printf("get_fo_zhi_11=%d\r\n",get_fo_zhi);

    czVal3 = (uint16_t)(reg_val2 & 0x3F);
    czVal3 = (uint16_t)((czVal3 << 8) | reg_val1);

    get_fo_zhi=haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CZ4_VAL1, &reg_val1, 1, haptic_data->i2c.hi2c);
														printf("get_fo_zhi_12=%d\r\n",get_fo_zhi);

    get_fo_zhi=haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CZ4_VAL2, &reg_val2, 1, haptic_data->i2c.hi2c);
														printf("get_fo_zhi_13=%d\r\n",get_fo_zhi);

    czVal4 = (uint16_t)(reg_val2 & 0x3F);
    czVal4 = (uint16_t)((czVal4 << 8) | reg_val1);

    get_fo_zhi=haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CZ5_VAL1, &reg_val1, 1, haptic_data->i2c.hi2c);
																printf("get_fo_zhi_14=%d\r\n",get_fo_zhi);

    get_fo_zhi= haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CZ5_VAL2, &reg_val2, 1, haptic_data->i2c.hi2c);
	 														printf("get_fo_zhi_15=%d\r\n",get_fo_zhi);

    czVal5 = (uint16_t)(reg_val2 & 0x3F);
    czVal5 = (uint16_t)((czVal5 << 8) | reg_val1);

    haptic_data->chip_config.f0 = ((czVal4 - czVal2) + (czVal5 - czVal3)) >> 1;
    haptic_data->chip_config.f0 = 192000 * 10 / haptic_data->chip_config.f0;
//    ics_info("%s f0 = %d\n", __func__, haptic_data->chip_config.f0);
//    printf("czVal1 = %d, czVal2 = %d,  czVal3 = %d, czVal4 = %d, czVal5 = %d\r\n", __func__, czVal1, czVal2, czVal3, czVal4, czVal5);
//	printf("%s f0 = %d\r\n", __func__, haptic_data->chip_config.f0);
		printf("czVal1 = %d, czVal2 = %d,  czVal3 = %d, czVal4 = %d, czVal5 = %d\r\n",czVal1, czVal2, czVal3, czVal4, czVal5);
		printf("f0 = %d\r\n",haptic_data->chip_config.f0);
#endif
    return 0;
}

static int32_t ics6b11_get_play_mode(struct ics_haptic_data *haptic_data){
    int32_t ret = 0;
    uint8_t reg_val = 0;

    ret = haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_PLAY_MODE, &reg_val, 1, haptic_data->i2c.hi2c);
    haptic_data->play_mode = (reg_val & 0x07);

    return ret;
}

static int32_t ics6b11_set_play_mode(struct ics_haptic_data *haptic_data, uint8_t mode_val){

    if(mode_val >= ICS6B11_PLAY_RAM_MODE && mode_val < ICS6B11_PLAY_AUTO_BREAK){
        haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_PLAY_MODE, &mode_val, 1, haptic_data->i2c.hi2c);
    }else{
        return -1;
    }

    haptic_data->play_mode = mode_val;

    return 0;
}

static int32_t ics6b11_play_go(struct ics_haptic_data *haptic_data){
    int32_t ret = 0;
    uint8_t reg_val = 0x01;

    ret = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_PLAY_CTRL, &reg_val, 1, haptic_data->i2c.hi2c);

    return ret;
}

static int32_t ics6b11_play_stop(struct ics_haptic_data *haptic_data){
    int32_t ret = 0;
    uint8_t reg_val = 0x00;
    ret = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_PLAY_CTRL, &reg_val, 1, haptic_data->i2c.hi2c);

    return ret;
}

static int32_t ics6b11_set_gain(struct ics_haptic_data *haptic_data, uint8_t gain_val){
    int32_t ret = 0;
    ret = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_GAIN_CFG, &gain_val, 1, haptic_data->i2c.hi2c);
    haptic_data->chip_config.gain = gain_val;

    return ret;
}

static int32_t ics6b11_set_max_bst_vol(struct ics_haptic_data *haptic_data, uint8_t max_bst_vol_val){
    int32_t ret = 0;
    ret = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BOOST_CFG3, &max_bst_vol_val, 1, haptic_data->i2c.hi2c);
    haptic_data->chip_config.max_bst_vol = max_bst_vol_val;

    return ret;
}

int32_t ics6b11_set_fifo_ae(struct ics_haptic_data *haptic_data, uint16_t fifo_ae_val){
    int32_t ret = 0;
    uint8_t reg_val = 0;

    reg_val = (fifo_ae_val & 0xFF);
    ret = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_FIFO_AE_L, &reg_val, 1, haptic_data->i2c.hi2c);
    printf("fifo_ae_write_1 = %d\r\n", reg_val);
    reg_val = ((fifo_ae_val & 0xFF00)) >> 8;
    ret = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_FIFO_AE_H, &reg_val, 1, haptic_data->i2c.hi2c);
    printf("fifo_ae_write_2 = %d\r\n", reg_val);

    haptic_data->chip_config.fifo_ae = fifo_ae_val;

    return ret;
}

static int32_t ics6b11_set_fifo_af(struct ics_haptic_data *haptic_data, uint16_t fifo_af_val){
    int32_t ret = 0;
    uint8_t reg_val = 0;

    reg_val = (fifo_af_val & 0xFF);
    ret = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_FIFO_AF_L, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val = ((fifo_af_val & 0xFF00)) >> 8;
    ret = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_FIFO_AF_H, &reg_val, 1, haptic_data->i2c.hi2c);

    haptic_data->chip_config.max_bst_vol = fifo_af_val;

    return ret;
}

static int32_t ics6b11_set_play_list(struct ics_haptic_data *haptic_data, const uint8_t *data, uint16_t size){
		uint16_t section_size = haptic_data->chip_config.wave_base_addr - haptic_data->chip_config.list_base_addr;
    uint8_t regh_val = haptic_data->chip_config.list_base_addr >> 8;
		uint8_t regl_val = haptic_data->chip_config.list_base_addr & 0x00FF;
		if (size > section_size)
		{
			return -1;
		}
		
		haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_ADDR_H, &regh_val, 1, haptic_data->i2c.hi2c);
		haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_ADDR_L, &regl_val, 1, haptic_data->i2c.hi2c);
		haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_DATA, data, size, haptic_data->i2c.hi2c);

	  return 0;
}

static int32_t ics6b11_set_waveform_data(struct ics_haptic_data *haptic_data, const uint8_t *data, uint16_t size){
		int16_t section_size = RT6010_MAX_RAM_SIZE - haptic_data->chip_config.wave_base_addr;
    uint8_t regh_val = haptic_data->chip_config.wave_base_addr >> 8;
		uint8_t regl_val = haptic_data->chip_config.wave_base_addr & 0x00FF;
		if (size > section_size)
		{
			return -1;
		}

		haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_ADDR_H, &regh_val, 1, haptic_data->i2c.hi2c);
		haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_ADDR_L, &regl_val, 1, haptic_data->i2c.hi2c);
		haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_DATA, data, size, haptic_data->i2c.hi2c);

		return 0;
}

static int32_t ics6b11_clear_stream_fifo(struct ics_haptic_data *haptic_data, uint8_t stream_index){
    int32_t retry = 0;
    uint8_t reg_val = 0;

    //clear fifo section
    reg_val = 0x01;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_RAM_CFG, &reg_val, 1, haptic_data->i2c.hi2c);

    do{
        haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_RAM_CFG, &reg_val, 1, haptic_data->i2c.hi2c);
    }while((reg_val & 0x01) && (retry++ < 10));
    
    return 0;
}

static int32_t ics6b11_set_stream_data(struct ics_haptic_data *haptic_data, const uint8_t *data, uint16_t size, uint8_t stream_index){
    int32_t ret = 0;
    ret =  haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_STREAM_DATA, data, size, haptic_data->i2c.hi2c);

    return ret;
}

static int32_t ics6b11_get_ram_data(struct ics_haptic_data *haptic_data, uint8_t *data, uint16_t *size){
		int32_t ret = 0;
	  uint32_t read_size = RT6010_MAX_RAM_SIZE;
		if (*size < RT6010_MAX_RAM_SIZE)
		{
			read_size = *size;
		}
		ret = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_DATA_READ, data, read_size, haptic_data->i2c.hi2c);

	  return ret;
}

static int32_t ics6b11_get_sys_state(struct ics_haptic_data *haptic_data){
    int32_t ret = 0;
    uint8_t reg_val = 0;
    ret = haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_SYS_STATUS1, &reg_val, 1, haptic_data->i2c.hi2c);
    haptic_data->sys_state = reg_val;

    return ret;
}

static int32_t ics6b11_set_brake_en(struct ics_haptic_data *haptic_data, uint8_t enable){
		uint8_t reg_val = 0;

		reg_val = enable ? 0x03 : 0x00;
		haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_BRAKE_CFG1, &reg_val, 1, haptic_data->i2c.hi2c);

		haptic_data->chip_config.brake_en = enable;

		return 0;
}


int32_t ics6b11_get_irq_state(struct ics_haptic_data *haptic_data){
    int32_t ret = 0;
    uint8_t reg_val = 0;

    ret = haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_INT_STATUS, &reg_val, 1, haptic_data->i2c.hi2c);
    haptic_data->irq_state = reg_val;
	
		int32_t result=	haptic_data->irq_state;
//		printf("result = %d\r\n", result);
	
	  haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_PROTECTION_STATUS1, &reg_val, 1, haptic_data->i2c.hi2c);
    int32_t ICS6B1X_REG_PROTECTION_STATUS1_reg_1 = reg_val;
//		printf("ICS6B1X_REG_PROTECTION_STATUS1_reg_1 = %d\r\n", ICS6B1X_REG_PROTECTION_STATUS1_reg_1);
	
	  haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_PROTECTION_STATUS2, &reg_val, 1, haptic_data->i2c.hi2c);
    int32_t ICS6B1X_REG_PROTECTION_STATUS1_reg_2 = reg_val;
//		printf("ICS6B1X_REG_PROTECTION_STATUS1_reg_2 = %d\r\n", ICS6B1X_REG_PROTECTION_STATUS1_reg_2);

    return ret;
}

static bool ics6b11_is_irq_play_done(struct ics_haptic_data *haptic_data){
    return ((haptic_data->irq_state & ICS6B11_BIT_INTS_DONE) > 0); 
}

static bool ics6b11_is_irq_fifo_ae(struct ics_haptic_data *haptic_data){
    return ((haptic_data->irq_state & ICS6B11_BIT_INTS_FIFO_AE) > 0); 
}

static bool ics6b11_is_irq_fifo_af(struct ics_haptic_data *haptic_data){
    return ((haptic_data->irq_state & ICS6B11_BIT_INTS_FIFO_AF) > 0); 
}

static bool ics6b11_is_irq_protection(struct ics_haptic_data *haptic_data){
    return ((haptic_data->irq_state & ICS6B11_BIT_INTS_PROT) > 0); 
}

int32_t ics6b11_stop_play(struct ics_haptic_data *haptic_data){
    return ics6b11_play_stop(haptic_data);
}

int32_t ics6b11_clear_protection(struct ics_haptic_data *haptic_data){
    uint8_t reg_val = 0;

    haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val |= 0x02;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val &= 0xFD;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);

    return 0;
}

int32_t rt6010_playlist_data(struct ics_haptic_data *haptic_data, const uint8_t* buf, int32_t size)
{
    int32_t res = 0;
    uint8_t reg_val;
    reg_val = 0x02;
    res = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_CFG, &reg_val, 1, haptic_data->i2c.hi2c);
	  struct RAM_PARAM *ram_param;
    ram_param = (struct RAM_PARAM*)&rt6010_config.ram_param;
    res = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_ADDR_L, &ram_param->ListBaseAddrL, 1, haptic_data->i2c.hi2c);
    res = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_ADDR_H, &ram_param->ListBaseAddrH, 1, haptic_data->i2c.hi2c);
    uint32_t copySize = MIN(size,RT6010_MAX_RAM_SIZE);
    res = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_DATA, (uint8_t*)buf, copySize, haptic_data->i2c.hi2c);

    return 0;
}

int32_t rt6010_waveform_data(struct ics_haptic_data *haptic_data, const uint8_t* wave_table_buf, int32_t table_size, const int8_t* wave_data_buf, int32_t data_size)
{
    int32_t res = 0;
    uint8_t reg_val;
    reg_val = 0x04;
    res = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_CFG, &reg_val, 1, haptic_data->i2c.hi2c);
    struct RAM_PARAM *ram_param;
    ram_param = (struct RAM_PARAM*)&rt6010_config.ram_param;
    res = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_ADDR_L, &ram_param->WaveBaseAddrL, 1, haptic_data->i2c.hi2c);
    res = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_ADDR_H, &ram_param->WaveBaseAddrH, 1, haptic_data->i2c.hi2c);
    res = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_DATA, (uint8_t*)wave_table_buf, table_size, haptic_data->i2c.hi2c);
    uint32_t copySize = MIN(data_size,RT6010_MAX_RAM_SIZE);
    res = haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_RAM_DATA, (uint8_t*)wave_data_buf, copySize, haptic_data->i2c.hi2c);

    return 0;
}


int32_t ics6b11_ram_play_demo(struct ics_haptic_data *haptic_data){
    uint8_t reg_val = 0;

    haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val |= 0x02;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val &= 0xFD;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);

    return 0;
}

int32_t ics6b11_stream_play_demo(struct ics_haptic_data *haptic_data){
    uint8_t reg_val = 0;

    haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val |= 0x02;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val &= 0xFD;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);

    return 0;
}

int32_t stream_play_demo_ex(struct ics_haptic_data *haptic_data){
    uint8_t reg_val = 0;

    haptic_data->i2c.i2c_read(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val |= 0x02;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);
    reg_val &= 0xFD;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);

    return 0;
}

int32_t autobrake_play_demo(struct ics_haptic_data *haptic_data){
    uint8_t reg_val = 0;

    return 0;
}

int32_t GPIO_Trigger_play_demo(struct ics_haptic_data *haptic_data){
    uint8_t reg_val = 0;

    return 0;
}

int32_t rt6010_clear_int(struct ics_haptic_data *haptic_data)
{
    uint8_t reg_val;
    return haptic_data->i2c.i2c_read(haptic_data->i2c.device_address, ICS6B1X_REG_INT_STATUS, &reg_val, 1, haptic_data->i2c.hi2c);
}


int32_t rt6010_boost_voltage(struct ics_haptic_data *haptic_data, RT6010_BOOST_VOLTAGE vout)
{
    int32_t res = 0;
    uint8_t reg_val;
    res = haptic_data->i2c.i2c_read(haptic_data->i2c.device_address, ICS6B1X_REG_BOOST_CFG3, &reg_val, 1, haptic_data->i2c.hi2c);

    reg_val = (reg_val & 0xF0) | ((uint8_t)vout & 0x0F);
    return haptic_data->i2c.i2c_write(haptic_data->i2c.device_address, ICS6B1X_REG_BOOST_CFG3, &reg_val, 1, haptic_data->i2c.hi2c);
}

int32_t ram_play_demo(struct ics_haptic_data *haptic_data)
{
    int32_t res = 0;
    // Clear all interruptions
    res = rt6010_clear_int(haptic_data);
    // Fill the list data and waveform data
    res = rt6010_playlist_data(haptic_data, list_data,LIST_DATA_LEN);
    uint8_t wave_table_buf[4];
    wave_table_buf[0] = 0x02;
    wave_table_buf[1] = 0x24;
    wave_table_buf[2] = (uint8_t)(WAVE_DATA_LEN >> 8);
    wave_table_buf[3] = (uint8_t)(WAVE_DATA_LEN & 0x00FF);
    // Fill the waveform data.
    res = rt6010_waveform_data(haptic_data, wave_table_buf, 4, (int8_t*)wave_data, WAVE_DATA_LEN_RAM);
    res = ics6b11_set_gain(haptic_data, 0x80);
    res = rt6010_boost_voltage(haptic_data, BOOST_VOUT_850);
    res = ics6b11_set_play_mode(haptic_data, ICS6B1X_BIT_PLAY_MODE_RAM);
    res = ics6b11_play_go(haptic_data);

    return 0;
}

int32_t stream_play_demo_proc(struct ics_haptic_data *haptic_data)
{
    uint8_t reg_val = 0; 
    while (1)
    {
        int16_t res = haptic_data->i2c.i2c_read(haptic_data->i2c.device_address, ICS6B1X_REG_INT_STATUS, &reg_val, 1, haptic_data->i2c.hi2c);
        if ((reg_val & ICS6B11_BIT_INTS_DONE) > 0)
        {
            return 0;
        }
        if ((reg_val & ICS6B11_BIT_INTS_PROT) > 0)
        {
            return -1;
        }
        if ((reg_val & ICS6B11_BIT_INTS_FIFO_AF) > 0)
        {
            stream_demo_flag = 0;
        }
        if ((reg_val & ICS6B11_BIT_INTS_FIFO_AE) > 0)
        {
            stream_demo_flag = 1;
        }
        if (stream_demo_flag == 1)
        {
            stream_demo_flag = 0; 

            int32_t stream_size = ((rt6010_config.ram_param.ListBaseAddrH << 8) | rt6010_config.ram_param.ListBaseAddrL)
                - ((rt6010_config.ram_param.FifoAEH << 8) | rt6010_config.ram_param.FifoAEL);
            stream_size = MIN(STREAM_DATA_LEN - data_demo_index, stream_size);

//            res = ics6b11_set_stream_data((const uint8_t*)ics6b11_f0_wave_data + data_demo_index, stream_size);
						res = ics6b11_set_stream_data(haptic_data, (uint8_t *)ics6b11_f0_wave_data, sizeof(ics6b11_f0_wave_data), stream_size);
            data_demo_index += stream_size;

            if (data_demo_index >= STREAM_DATA_LEN)
            {
                break;
            }
        }
    }
    return 0;
}


int32_t stream_play_demo(struct ics_haptic_data *haptic_data)
{
	#if 0
    int32_t res = 0;
    uint8_t regvalue = 0x01;
#endif
      ics6b11_get_irq_state(haptic_data);
      ics6b11_get_f0(haptic_data);
      ics6b11_get_irq_state(haptic_data);
			
    return 0;
}



int32_t rt6010_set_gain(struct ics_haptic_data *haptic_data, uint8_t gain_val)
{
    return ics6b11_set_gain(haptic_data, gain_val);
}

int32_t test_case1(struct ics_haptic_data *haptic_data) //just for test
{
	  uint8_t reg_val;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_LRA_F0_CFG1, &reg_val, 1, haptic_data->i2c.hi2c);
	    reg_val = 0x04;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_LRA_F0_CFG2, &reg_val, 1, haptic_data->i2c.hi2c);
      reg_val = 0x26;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG3, &reg_val, 1, haptic_data->i2c.hi2c);
      reg_val = 0x20;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_BEMF_CFG4, &reg_val, 1, haptic_data->i2c.hi2c);
      reg_val = 0x01;
    haptic_data->i2c.i2c_write(haptic_data->i2c.device_address,ICS6B1X_REG_DETECT_FO_CFG, &reg_val, 1, haptic_data->i2c.hi2c);
	
	  return 0;
}

int32_t test_case2(struct ics_haptic_data *haptic_data) //just for test
{
    // Play and wait for play done!
    ics6b11_play_stop(haptic_data);
    ics6b11_clear_stream_fifo(haptic_data, 1);
		ics6b11_set_gain(haptic_data, 0x64); //0x23

    ics6b11_set_play_mode(haptic_data, ICS6B11_PLAY_STREAM_MODE);
    ics6b11_play_go(haptic_data);
    ics6b11_set_stream_data(haptic_data, (uint8_t *)ics6b11_f0_wave_data, sizeof(ics6b11_f0_wave_data), 1);
	
		return 0;
}

int32_t test_case3(struct ics_haptic_data *haptic_data) //just for test
{
    // Play and wait for play done!
    ics6b11_play_stop(haptic_data);
		ics6b11_set_gain(haptic_data, 0x23); //0x23
    ics6b11_set_play_list(haptic_data, (uint8_t *)list_data, LIST_DATA_LEN);
	  ics6b11_set_waveform_data(haptic_data, (uint8_t *)ram_wave_data, WAVE_DATA_LEN);
    ics6b11_set_play_mode(haptic_data, ICS6B11_PLAY_RAM_MODE);
    ics6b11_play_go(haptic_data);
	
		return 0;
}

struct ics_haptic_func ics6b11_func_list ={
    .chip_init = ics6b11_chip_init,
    .get_chip_id = ics6b11_get_chip_id,
    .get_reg = ics6b11_get_reg,
    .set_reg = ics6b11_set_reg,
    .get_f0 = ics6b11_get_f0,
    .get_play_mode = ics6b11_get_play_mode,
    .set_play_mode = ics6b11_set_play_mode,
    .play_go = ics6b11_play_go,
    .play_stop = ics6b11_play_stop,
    .set_gain = ics6b11_set_gain,
    .set_max_bst_vol = ics6b11_set_max_bst_vol,
    .set_fifo_ae = ics6b11_set_fifo_ae,
    .set_fifo_af = ics6b11_set_fifo_af,
    .set_play_list = ics6b11_set_play_list,
    .set_waveform_data = ics6b11_set_waveform_data,
    .clear_stream_fifo = ics6b11_clear_stream_fifo,
    .set_stream_data = ics6b11_set_stream_data,
    .get_ram_data = ics6b11_get_ram_data,
    .get_sys_state = ics6b11_get_sys_state,
    .set_brake_en = ics6b11_set_brake_en,
    .get_irq_state = ics6b11_get_irq_state,
    .is_irq_play_done = ics6b11_is_irq_play_done,
    .is_irq_fifo_ae = ics6b11_is_irq_fifo_ae,
    .is_irq_fifo_af = ics6b11_is_irq_fifo_af,
    .is_irq_protection = ics6b11_is_irq_protection,
    .clear_protection = ics6b11_clear_protection
};
