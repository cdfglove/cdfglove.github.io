#ifndef BSP_ICS6B11_H
#define BSP_ICS6B11_H

#include "stdint.h"
#include "stdbool.h"
#include "stm32h7xx_hal.h"

/******************************************************************************
 * ICS6b11 chip id
******************************************************************************/
#define ICS6B11_CHIP_ID                     0x6B
#define LINEAR_MAX_NUM                      6
/******************************************************************************
 * ics6b1x register address
******************************************************************************/
#define ICS6B1X_REG_DEV_ID                  0x00
#define ICS6B1X_REG_REV_ID                  0x01
#define ICS6B1X_REG_SOFT_RESET              0x02
#define ICS6B1X_REG_SYS_STATUS1             0x03
#define ICS6B1X_REG_SYS_STATUS2             0x04
#define ICS6B1X_REG_INT_STATUS              0x05
#define ICS6B1X_REG_INT_MASK                0x06
#define ICS6B1X_REG_RAM_CFG                 0x07
#define ICS6B1X_REG_RAM_ADDR_L              0x08
#define ICS6B1X_REG_RAM_ADDR_H              0x09
#define ICS6B1X_REG_RAM_DATA                0x0A
#define ICS6B1X_REG_STREAM_DATA             0x0B
#define ICS6B1X_REG_FIFO_AE_L               0x0C
#define ICS6B1X_REG_FIFO_AE_H               0x0D
#define ICS6B1X_REG_FIFO_AF_L               0x0E
#define ICS6B1X_REG_FIFO_AF_H               0x0F
#define ICS6B1X_REG_PLAY_CFG                0x10
#define ICS6B1X_REG_PLAY_MODE               0x11
#define ICS6B1X_REG_PLAY_CTRL               0x12
#define ICS6B1X_REG_GPIO1_POS_ENTRY         0x13
#define ICS6B1X_REG_GPIO1_NEG_ENTRY         0x14
#define ICS6B1X_REG_GPIO2_POS_ENTRY         0x15
#define ICS6B1X_REG_GPIO2_NEG_ENTRY         0x16
#define ICS6B1X_REG_GPIO3_POS_ENTRY         0x17
#define ICS6B1X_REG_GPIO3_NEG_ENTRY         0x18
#define ICS6B1X_REG_GPIO_STATUS             0x19
#define ICS6B1X_REG_PRIORITY_CFG            0x1A
#define ICS6B1X_REG_WAVE_BASE_ADDR_L        0x1C
#define ICS6B1X_REG_WAVE_BASE_ADDR_H        0x1D
#define ICS6B1X_REG_LIST_BASE_ADDR_L        0x1E
#define ICS6B1X_REG_LIST_BASE_ADDR_H        0x1F
#define ICS6B1X_REG_GAIN_CFG                0x20
#define ICS6B1X_REG_SYS_CFG                 0x23
#define ICS6B1X_REG_STATE_MACHINE_CFG       0x25
#define ICS6B1X_REG_PROTECTION_STATUS1      0x26
#define ICS6B1X_REG_PROTECTION_STATUS2      0x27
#define ICS6B1X_REG_PROTECTION_MASK1        0x28
#define ICS6B1X_REG_PROTECTION_MASK2        0x29
#define ICS6B1X_REG_ERROR_CODE              0x2C
#define ICS6B1X_REG_LRA_F0_CFG1             0x2D
#define ICS6B1X_REG_LRA_F0_CFG2             0x2E
#define ICS6B1X_REG_DETECT_FO_CFG           0x2F
#define ICS6B1X_REG_BEMF_CZ1_VAL1           0x30
#define ICS6B1X_REG_BEMF_CZ1_VAL2           0x31
#define ICS6B1X_REG_BEMF_CZ2_VAL1           0x32
#define ICS6B1X_REG_BEMF_CZ2_VAL2           0x33
#define ICS6B1X_REG_BEMF_CZ3_VAL1           0x34
#define ICS6B1X_REG_BEMF_CZ3_VAL2           0x35
#define ICS6B1X_REG_BEMF_CZ4_VAL1           0x36
#define ICS6B1X_REG_BEMF_CZ4_VAL2           0x37
#define ICS6B1X_REG_BEMF_CZ5_VAL1           0x38
#define ICS6B1X_REG_BEMF_CZ5_VAL2           0x39
#define ICS6B1X_REG_BRAKE_CFG1              0x3A
#define ICS6B1X_REG_BRAKE_CFG2              0x3B
#define ICS6B1X_REG_BRAKE_CFG3              0x3c
#define ICS6B1X_REG_BRAKE_CFG4              0x3D
#define ICS6B1X_REG_BRAKE_CFG5              0x3E
#define ICS6B1X_REG_BRAKE_CFG6              0x3F
#define ICS6B1X_REG_BRAKE_CFG7              0x40
#define ICS6B1X_REG_BRAKE_CFG8              0x41
#define ICS6B1X_REG_TRACK_CFG1              0x44
#define ICS6B1X_REG_TRACK_CFG2              0x45
#define ICS6B1X_REG_TRACK_CFG3              0x46
#define ICS6B1X_REG_TRACK_F0_VAL1           0x47
#define ICS6B1X_REG_TRACK_F0_VAL2           0x48
#define ICS6B1X_REG_TIMING_CFG1             0x49
#define ICS6B1X_REG_BEMF_CFG1               0x50
#define ICS6B1X_REG_BEMF_CFG2               0x51
#define ICS6B1X_REG_BEMF_CFG3               0x52
#define ICS6B1X_REG_BEMF_CFG4               0x53
#define ICS6B1X_REG_BOOST_CFG1              0x55
#define ICS6B1X_REG_BOOST_CFG2              0x56
#define ICS6B1X_REG_BOOST_CFG3              0x57
#define ICS6B1X_REG_BOOST_CFG4              0x58
#define ICS6B1X_REG_BOOST_CFG5              0x59
#define ICS6B1X_REG_PA_CFG1                 0x5A
#define ICS6B1X_REG_PA_CFG2                 0x5B
#define ICS6B1X_REG_PMU_CFG1                0x5C
#define ICS6B1X_REG_PMU_CFG2                0x5D
#define ICS6B1X_REG_PMU_CFG3                0x5E
#define ICS6B1X_REG_PMU_CFG4                0x5F
#define ICS6B1X_REG_OSC_CFG1                0x60
#define ICS6B1X_REG_OSC_CFG2                0x61
#define ICS6B1X_REG_INT_CFG                 0x62
#define ICS6B1X_REG_GPIO_CFG1               0x63
#define ICS6B1X_REG_GPIO_CFG2               0x64
#define ICS6B1X_REG_GPIO_CFG3               0x65
#define ICS6B1X_REG_EFS_WR_DATA             0x66
#define ICS6B1X_REG_EFS_RD_DATA             0x67
#define ICS6B1X_REG_EFS_ADDR_INDEX          0x68
#define ICS6B1X_REG_EFS_MODE_CTRL           0x69
#define ICS6B1X_REG_EFS_PGM_STROBE_WIDTH    0x6A
#define ICS6B1X_REG_EFS_READ_STROBE_WIDTH   0x6B
#define ICS6B1X_REG_RAM_DATA_READ           0xFF

#define I2C_ADDRESS_1     (0x5f<<1)
#define I2C_ADDRESS_2     (0x60<<1)
#define I2C_ADDRESS_3     (0x5e<<1)



/******************************************************************************
 * ics6b1x register bit detail
******************************************************************************/
// ICS6B1X_REG_PLAY_MODE
#define ICS6B1X_BIT_PLAY_MODE_MASK          (7 << 0)
#define ICS6B1X_BIT_PLAY_MODE_RAM           (1 << 0)
#define ICS6B1X_BIT_PLAY_MODE_STREAM        (2 << 0)
#define ICS6B1X_BIT_PLAY_MODE_TRACK         (3 << 0)

// ICS6B1X_REG_PLAY_CTRL
#define ICS6B1X_BIT_GO_MASK                 (1 << 0)
#define ICS6B1X_BIT_GO_START                (1 << 0)
#define ICS6B1X_BIT_GO_STOP                 (0 << 0)

// ICS6B1X_REG_INT_STATUS
#define ICS6B1X_BIT_INTS_PLAYDONE           (1 << 3)
#define ICS6B1X_BIT_INTS_FIFO_AE            (1 << 2)
#define ICS6B1X_BIT_INTS_FIFO_AF            (1 << 1)
#define ICS6B1X_BIT_INTS_PROTECTION         (1 << 0)

// ICS6B1X_REG_EFS_MODE_CTRL
#define ICS6B1X_BIT_EFS_READ                (1 << 1)
#define ICS6B1X_BIT_EFS_PGM                 (1 << 0)

// PMU_CFG3
#define ICS6B1X_BIT_OSC_LDO_TRIM_MASK       (3 << 6)
#define ICS6B1X_BIT_PMU_LDO_TRIM_MASK       (3 << 4)
#define ICS6B1X_BIT_PMU_VBAT_TRIM_MASK      (3 << 0)

// PMU_CFG4
#define ICS6B1X_BIT_BIAS_1P2V_TRIM_MASK     (0x0F << 4)
#define ICS6B1X_BIT_BIAS_I_TRIM_MASK        (0x0F << 0)

// BOOST_CFG3
#define ICS6B1X_BIT_BST_VOUT_TRIM_MASK      (0x0F << 4)

// OSC_CFG1
#define ICS6B1X_BIT_OSC_TRIM_MASK           (0xFF << 0)

// BEMF_CFG1
#define ICS6B1X_BIT_BEMF_STAGE_TRIM_MASK    (0X0F << 0)

/******************************************************************************
 * ics6b1x efuse layout
******************************************************************************/
#define ICS6B1X_EFS_BIAS_1P2V_TRIM_OFFSET   0x00
#define ICS6B1X_EFS_BIAS_I_TRIM_OFFSET      0x04
#define ICS6B1X_EFS_PMU_LDO_TRIM_OFFSET     0x08
#define ICS6B1X_EFS_OSC_LDO_TRIM_OFFSET     0x09
#define ICS6B1X_EFS_OSC_TRIM_OFFSET         0x0A
#define ICS6B1X_EFS_VBAT_OFFSET_OFFSET      0x12
#define ICS6B1X_EFS_RL_OFFSET_OFFSET        0x17
#define ICS6B1X_EFS_VERSION_OFFSET          0x1E

#define ICS6B1X_EFS_BIAS_1P2V_TRIM_MASK     0x0F
#define ICS6B1X_EFS_BIAS_I_TRIM_MASK        0xF0
#define ICS6B1X_EFS_PMU_LDO_TRIM_MASK       0x100
#define ICS6B1X_EFS_OSC_LDO_TRIM_MASK       0x200
#define ICS6B1X_EFS_OSC_TRIM_MASK           0x3FC00
#define ICS6B1X_EFS_VBAT_OFFSET_MASK        0x7C0000
#define ICS6B1X_EFS_RL_OFFSET_MASK          0x3F800000
#define ICS6B1X_EFS_VERSION_MASK            0xC0000000


#define RAM_DATA_READ       0xFF

#define RAM_SIZE	0xC00

#define ICS6B11_BIT_SYSST2_FIFO_AF  (1 << 4)
#define ICS6B11_BIT_SYSST2_FIFO_AE  (1 << 5)

#define ICS6B11_BIT_INTS_PROT       (1 << 0)
#define ICS6B11_BIT_INTS_FIFO_AF    (1 << 1)
#define ICS6B11_BIT_INTS_FIFO_AE    (1 << 2)
#define ICS6B11_BIT_INTS_DONE       (1 << 3)

#define ICS6B11_BIT_INTM_FIFO_AE_MASK   (1 << 2)
#define ICS6B11_BIT_INTM_FIFO_AE_EN     (0 << 2)  
#define ICS6B11_BIT_INTM_FIFO_AE_OFF    (1 << 2)
#define ICS6B11_BIT_INTM_DONE_MASK      (1 << 3)
#define ICS6B11_BIT_INTM_DONE_EN        (0 << 3)
#define ICS6B11_BIT_INTM_DONE_OFF       (1 << 3)

struct RAM_PARAM
{
    uint8_t ListBaseAddrL;
    uint8_t ListBaseAddrH;
    uint8_t WaveBaseAddrL;
    uint8_t WaveBaseAddrH;
    uint8_t FifoAEL;
    uint8_t FifoAEH;
    uint8_t FifoAFL;
    uint8_t FifoAFH;
};

struct RT6010_CONFIG {
    uint8_t chip_id;
    uint16_t f0;

    int32_t vbat_det_trim;
    uint8_t rl_det_trim;
    float vbat;
    float rl;

    struct RAM_PARAM ram_param;
};

typedef enum
{
    BOOST_VOUT_600    = 0,
    BOOST_VOUT_625    = 1,
    BOOST_VOUT_650    = 2,
    BOOST_VOUT_675    = 3,
    BOOST_VOUT_700    = 4,
    BOOST_VOUT_725    = 5,
    BOOST_VOUT_750    = 6,
    BOOST_VOUT_775    = 7,
    BOOST_VOUT_800    = 8,
    BOOST_VOUT_825    = 9,
    BOOST_VOUT_850    = 10,
    BOOST_VOUT_875    = 11,
    BOOST_VOUT_900    = 12,
    BOOST_VOUT_925    = 13,
    BOOST_VOUT_100    = 14,
    BOOST_VOUT_110    = 15
} RT6010_BOOST_VOLTAGE;

enum {
    ICS6B11_PLAY_RAM_MODE = 0x01,
    ICS6B11_PLAY_STREAM_MODE,
    ICS6B11_PLAY_GPIO_TRIGGER_MODE,
		ICS6B11_PLAY_AUTO_TRACKING_MODE,
		ICS6B11_PLAY_AUTO_BREAK
};

struct ics_haptic_chip_config{
    uint8_t chip_id;
    uint16_t reg_size;
    uint16_t ram_size;
    uint16_t sys_f0;
    uint16_t f0;
    uint16_t list_base_addr;
    uint16_t wave_base_addr;
    uint16_t fifo_ae;
    uint16_t fifo_af;
    uint16_t fifo_size;
    uint16_t list_section_size;
    uint16_t wave_section_size;
    uint8_t gain;
    uint8_t max_bst_vol;
	  uint8_t brake_en;
};

typedef struct{
    int32_t (*i2c_read)(uint8_t device_address, uint8_t reg_addr, uint8_t *data, uint16_t data_length, I2C_HandleTypeDef *hi2c);
    int32_t (*i2c_write)(uint8_t device_address, uint8_t reg_addr, const uint8_t *data, uint16_t data_length, I2C_HandleTypeDef *hi2c);
    I2C_HandleTypeDef *hi2c;
    uint8_t device_address; 
} ics6b11_i2c;

struct ics_haptic_data{
    ics6b11_i2c i2c;
    struct ics_haptic_chip_config chip_config;
    uint8_t play_mode;
    uint8_t sys_state;
    uint8_t irq_state;
    struct ics_haptic_func *func;
    uint8_t device_address; 
};

struct ics_haptic_func{
    int32_t (*chip_init)(struct ics_haptic_data *, I2C_HandleTypeDef *);
    int32_t (*get_chip_id)(struct ics_haptic_data *);
    int32_t (*get_reg)(struct ics_haptic_data *, uint8_t, uint8_t *);
    int32_t (*set_reg)(struct ics_haptic_data *, uint8_t, uint8_t);
    int32_t (*get_f0)(struct ics_haptic_data *);
    int32_t (*get_play_mode)(struct ics_haptic_data *);
    int32_t (*set_play_mode)(struct ics_haptic_data *, uint8_t);
    int32_t (*play_go)(struct ics_haptic_data *);
    int32_t (*play_stop)(struct ics_haptic_data *);
    int32_t (*get_play_status)(struct ics_haptic_data *);
    int32_t (*set_brake_en)(struct ics_haptic_data *, uint8_t);
    int32_t (*set_gain)(struct ics_haptic_data *, uint8_t);
    int32_t (*set_max_bst_vol)(struct ics_haptic_data *, uint8_t);
    int32_t (*set_fifo_ae)(struct ics_haptic_data *, uint16_t);
    int32_t (*set_fifo_af)(struct ics_haptic_data *, uint16_t);
    int32_t (*set_play_list)(struct ics_haptic_data *, const uint8_t *, uint16_t);
    int32_t (*get_ram_data)(struct ics_haptic_data *, uint8_t *, uint16_t *);
    int32_t (*set_waveform_data)(struct ics_haptic_data *, const uint8_t *, uint16_t);
    int32_t (*clear_stream_fifo)(struct ics_haptic_data *, uint8_t);
    int32_t (*set_stream_data)(struct ics_haptic_data *, const uint8_t *, uint16_t, uint8_t);
    int32_t (*get_sys_state)(struct ics_haptic_data *);
    int32_t (*get_irq_state)(struct ics_haptic_data *);
    bool (*is_irq_play_done)(struct ics_haptic_data *);
    bool (*is_irq_fifo_ae)(struct ics_haptic_data *);
    bool (*is_irq_fifo_af)(struct ics_haptic_data *);
    bool (*is_irq_protection)(struct ics_haptic_data *);
    int32_t (*clear_protection)(struct ics_haptic_data *);
};

extern struct ics_haptic_func ics6b11_func_list;

int ics6b11_chip_init(struct ics_haptic_data *haptic_data, I2C_HandleTypeDef *hi2c);

int32_t ics6b11_get_f0(struct ics_haptic_data *haptic_data);

int32_t ics6b11_get_irq_state(struct ics_haptic_data *haptic_data);

int32_t ics6b11_clear_protection(struct ics_haptic_data *haptic_data);
int32_t ics6b11_stop_play(struct ics_haptic_data *haptic_data);
int32_t ics6b11_set_fifo_ae(struct ics_haptic_data *haptic_data, uint16_t fifo_ae_val);

int32_t test_case2(struct ics_haptic_data *haptic_data);//just for test
int32_t test_case1(struct ics_haptic_data *haptic_data); //just for test
int32_t test_case3(struct ics_haptic_data *haptic_data); //just for test

int32_t ram_play_demo(struct ics_haptic_data *haptic_data);
void ics6b11_init_i2c(struct ics_haptic_data *haptic_data, I2C_HandleTypeDef *hi2c , uint8_t device_address);
int32_t rt6010_set_gain(struct ics_haptic_data *haptic_data, uint8_t gain_val);
int32_t stream_play_demo(struct ics_haptic_data *haptic_data);

typedef struct {
    uint8_t mode;       
    uint8_t gain;       
} LinearMotoCmd_t;

extern LinearMotoCmd_t linearMotoPlay[LINEAR_MAX_NUM];
#endif
