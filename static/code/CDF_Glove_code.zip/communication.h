#ifndef __COMMUNICATION_H
#define __COMMUNICATION_H

#include "main.h"
#include "IPC/ring_buffer.h"
#include "motor/motor.h"
#include "protocol/modbus.h"

#define UART1_CMD_BUFFER_SIZE 4
#define UART2_CMD_BUFFER_SIZE 4

void Communication_Init(void);
void CommunicationLoop(void const *argument);

#endif // __COMMUNICATION_H
