#ifndef __FLASH_H
#define	__FLASH_H

#include "stm32h7xx_hal.h"
#include "main.h"
static uint32_t GetSector(uint32_t Address);
int FlashWrite();
int FlashRead();






#endif /* __INTERNAL_FLASH_H */