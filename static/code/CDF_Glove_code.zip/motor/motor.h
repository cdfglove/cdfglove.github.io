#ifndef __MOTOR_H
#define __MOTOR_H

#include "main.h"
#include "app_type.h"
#include "../IPC/ring_buffer.h"
#include "../Libraries/SCSLib/SCServo.h"
#include <stdint.h>

#define MOTOR_ID_OFFSET 0x01




#define MAX_CURRENT_VALUE 2047
#define MAX_SPEED_VALUE 32767

enum {
    MOTOR_POS_SERVO_MODE = 0,
    MOTOR_CONSTANT_SPEED_MODE,
    MOTOR_PWM_SPEED_MODE,
    MOTOR_TORQUE_MODE
};

typedef struct {
    uint16_t target_pos[MAX_MOTOR_NUM];
    uint16_t accelerate[MAX_MOTOR_NUM];
    uint16_t torque[MAX_MOTOR_NUM];
    uint8_t mode;
    uint8_t torque_enable;
    uint8_t motor_id;
} MotorCmd_t;

void MotorControl_Init(void);
RingBufferStatus_t MotorControl_AddCommand(const MotorCmd_t *cmd);
void MotorControlLoop(const void *argument);
MotorStatus_t MotorControl_GetStatus(uint8_t motor_id);
RingBufferStatus_t MotorControl_GetAllStatus(MotorStatus_t status[MAX_MOTOR_NUM]);
void UpdateMotorStatus(uint8_t motor_id, MotorStatus_t *status);
void MotorControl_ForceRefreshPositions(void);
void MotorControl_Init(void);
RingBufferStatus_t MotorControl_AddCommand(const MotorCmd_t *cmd);
void MotorControlLoop(const void *argument);
MotorStatus_t MotorControl_GetStatus(uint8_t motor_id);
RingBufferStatus_t MotorControl_GetAllStatus(MotorStatus_t status[MAX_MOTOR_NUM]);
void UpdateMotorStatus(uint8_t motor_id, MotorStatus_t *status);
void MotorControl_ForceRefreshPositions(void);

#endif // __MOTOR_H
