#ifndef __SERVO_BENCHMARK_H
#define __SERVO_BENCHMARK_H

#include <stdint.h>

void ServoBus_Benchmark_Run(void);

#endif // __SERVO_BENCHMARK_H
 