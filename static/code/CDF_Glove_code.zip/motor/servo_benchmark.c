#include "servo_benchmark.h"
#include "SCServo.h"
#include "SCSCL.h"
#include "logger/logger.h"
#include "usart.h"

// ...existing code...
typedef struct {
	uint32_t count;
	uint32_t total_us;
	uint32_t min_us;
	uint32_t max_us;
} bench_stats_t;

static inline uint32_t now_us(void)
{
	// ...existing code...
	return HAL_GetTick() * 1000U;
}

static void stats_init(bench_stats_t *s)
{
	s->count = 0;
	s->total_us = 0;
	s->min_us = 0xFFFFFFFFU;
	s->max_us = 0;
}

static void stats_add(bench_stats_t *s, uint32_t dt_us)
{
	s->count++;
	s->total_us += dt_us;
	if (dt_us < s->min_us) s->min_us = dt_us;
	if (dt_us > s->max_us) s->max_us = dt_us;
}

static void print_stats(const char *name, const bench_stats_t *s)
{
	if (s->count == 0) return;
	uint32_t avg = s->total_us / s->count;
	printf("[SERVO-BENCH] %-12s: n=%lu avg=%luus min=%luus max=%luus\r\n",
	       name, (unsigned long)s->count, (unsigned long)avg,
	       (unsigned long)s->min_us, (unsigned long)s->max_us);
}

void ServoBus_Benchmark_Run(void)
{
	const uint8_t ids[] = {1,2,3,4,5};
	const uint32_t iterations = 50;
	const uint16_t write_pos = 2000;
	const uint16_t write_time = 0;
	const uint16_t write_speed = 600;

	bench_stats_t t_write, t_read, t_rtt, t_batch_read;
	stats_init(&t_write);
	stats_init(&t_read);
	stats_init(&t_rtt);
	stats_init(&t_batch_read);

	// 单 ID 写位置
	for (uint32_t n = 0; n < iterations; n++) {
		for (uint32_t k = 0; k < sizeof(ids); k++) {
			uint8_t id = ids[k];
			uint32_t t0 = now_us();
			int ret = WritePos(id, write_pos, write_time, write_speed);
			uint32_t t1 = now_us();
			stats_add(&t_write, t1 - t0);
			if (ret <= 0) {
				LOG_WARN("[SERVO-BENCH] WritePos fail id=%d ret=%d\r\n", id, ret);
			}
			HAL_Delay(1);
		}
	}

	// 单 ID 读位置
	for (uint32_t n = 0; n < iterations; n++) {
		for (uint32_t k = 0; k < sizeof(ids); k++) {
			uint8_t id = ids[k];
			uint32_t t0 = now_us();
			int pos = ReadPos(id);
			uint32_t t1 = now_us();
			stats_add(&t_read, t1 - t0);
			if (pos < 0) {
				LOG_WARN("[SERVO-BENCH] ReadPos fail id=%d\r\n", id);
			}
			HAL_Delay(1);
		}
	}

	// 往返（写后立即读）
	for (uint32_t n = 0; n < iterations; n++) {
		for (uint32_t k = 0; k < sizeof(ids); k++) {
			uint8_t id = ids[k];
			uint32_t t0 = now_us();
			( void )WritePos(id, write_pos, write_time, write_speed);
			int pos = ReadPos(id);
			uint32_t t1 = now_us();
			stats_add(&t_rtt, t1 - t0);
			if (pos < 0) {
				LOG_WARN("[SERVO-BENCH] RTT read fail id=%d\r\n", id);
			}
			HAL_Delay(1);
		}
	}

	// 批量读（遍历 5 个 ID）
	for (uint32_t n = 0; n < iterations; n++) {
		uint32_t t0 = now_us();
		for (uint32_t k = 0; k < sizeof(ids); k++) {
			( void )ReadPos(ids[k]);
		}
		uint32_t t1 = now_us();
		stats_add(&t_batch_read, t1 - t0);
		HAL_Delay(1);
	}

	printf("\r\n[SERVO-BENCH] Results (USART3 @500kbaud)\r\n");
	print_stats("write_pos", &t_write);
	print_stats("read_pos", &t_read);
	print_stats("rtt_wr_rd", &t_rtt);
	print_stats("batch_read5", &t_batch_read);
	printf("[SERVO-BENCH] End\r\n\r\n");
} 