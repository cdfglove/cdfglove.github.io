/**
    ******************************************************************************
    * @file    motor.c
    * @brief
    ******************************************************************************
    */
#include "motor.h"
#include "logger/logger.h"
#include "SCServo.h"
#include "IPC/d_buffer.h"
// #include "servo_async.h"
#include <string.h>
#include <stdlib.h>
#include <math.h>

static MotorCmd_t cmd_buffer[MOTOR_BUFFER_SIZE];
static RingBuffer_t motor_ctrl_cmd_buffer;

static MotorStatus_t status_buffers[MAX_MOTOR_NUM][2];
static DoubleBuffer_t motor_status_dbs[MAX_MOTOR_NUM];

// ...existing code...
typedef struct {
    uint32_t last_fail_time;
    uint32_t consecutive_fails;
    uint32_t last_log_time;
    bool is_blacklisted;
} MotorErrorState_t;

static MotorErrorState_t motor_error_states[MAX_MOTOR_NUM] = {0};

#define MAX_CONSECUTIVE_FAILS 5
#define BLACKLIST_DURATION_MS 3000
#define LOG_THROTTLE_INTERVAL_MS 1000

void MotorControl_Init(void)
{
    RingBuffer_Init(&motor_ctrl_cmd_buffer, cmd_buffer, 2, sizeof(MotorCmd_t));

    for(int i = 0; i < MAX_MOTOR_NUM; i++) {
        DoubleBuffer_Init(&motor_status_dbs[i], 
                          &status_buffers[i][0], 
                          &status_buffers[i][1], 
                          1,  // 每个缓冲区只存一个状态
                          sizeof(MotorStatus_t));
    }
    
    // ...existing code...
}

void UpdateMotorStatus(uint8_t motor_id, MotorStatus_t *status)
{
    // if(motor_id >= MAX_MOTOR_NUM || status == NULL) {
        if(status == NULL) {
        LOG_ERROR("Invalid motor id[%d] or status is null.\r\n", motor_id);
        return ;
    }
    
    status->timestamp = HAL_GetTick();
    MotorStatus_t *write_buffer = DoubleBuffer_GetWriteBuffer(&motor_status_dbs[motor_id]);
    *write_buffer = *status;
    DoubleBuffer_SwapBuffers(&motor_status_dbs[motor_id]);
}

// ...existing code...
static int ReadPosWithRetry(uint8_t id, uint16_t *pos_out)
{
    uint8_t motor_index = id - MOTOR_ID_OFFSET;
    if (motor_index >= MAX_MOTOR_NUM) return 0;
    
    uint32_t current_time = HAL_GetTick();
    MotorErrorState_t *error_state = &motor_error_states[motor_index];
    
    // ...existing code...
    if (error_state->is_blacklisted) {
        if (current_time - error_state->last_fail_time < BLACKLIST_DURATION_MS) {
            return 0;
        } else {
            // ...existing code...
            error_state->is_blacklisted = false;
            error_state->consecutive_fails = 0;
        }
    }
    
    int max_attempts = 3;
    for (int attempt = 1; attempt <= max_attempts; attempt++) {
        int pos = ReadPos(id);
        if (pos >= 0) {
            if (pos_out) { *pos_out = (uint16_t)pos; }
            // ...existing code...
            error_state->consecutive_fails = 0;
            error_state->is_blacklisted = false;
            return 1;
        }
        
    // ...existing code...
        if (current_time - error_state->last_log_time >= LOG_THROTTLE_INTERVAL_MS) {
            LOG_WARN("ReadPos FAIL: ID=%d (attempt %d/%d), consecutive_fails=%d\r\n", 
                     id, attempt, max_attempts, error_state->consecutive_fails + 1);
            error_state->last_log_time = current_time;
        }
        
        HAL_Delay(1);
    }
    
    // ...existing code...
    error_state->consecutive_fails++;
    error_state->last_fail_time = current_time;
    
    // ...existing code...
    if (error_state->consecutive_fails >= MAX_CONSECUTIVE_FAILS) {
        error_state->is_blacklisted = true;
        LOG_ERROR("Motor ID=%d blacklisted due to %d consecutive failures\r\n", 
                  id, error_state->consecutive_fails);
    }
    
    return 0;
}

// ...existing code...
static void ReadMotorStatusSync(void)
{
    static uint32_t last_read_start = 0;
    uint32_t now = HAL_GetTick();
    // 50Hz 读取频率
    if (now - last_read_start < 20) {
        return;
    }
    last_read_start = now;

    for (int i = 0; i < MAX_MOTOR_NUM; i++) {
        uint8_t id = i + MOTOR_ID_OFFSET;
        uint16_t pos = 0;
        if (ReadPosWithRetry(id, &pos)) {
            MotorStatus_t status = (MotorStatus_t){0};
            status.position = pos;
            status.timestamp = HAL_GetTick();
            UpdateMotorStatus(i, &status);
        }
    // ...existing code...
        HAL_Delay(1);
    }
}

void MotorControl_ForceRefreshPositions(void)
{
    for (int i = 0; i < MAX_MOTOR_NUM; i++) {
        uint8_t id = i + MOTOR_ID_OFFSET;
        uint16_t pos = 0;
        if (ReadPosWithRetry(id, &pos)) {
            MotorStatus_t status = (MotorStatus_t){0};
            status.position = pos;
            status.timestamp = HAL_GetTick();
            UpdateMotorStatus(i, &status);
        }
        HAL_Delay(1);
    }
}


MotorStatus_t MotorControl_GetStatus(uint8_t motor_id)
{
    MotorStatus_t status = {0};
    // ...existing code...
    if(motor_id < MOTOR_ID_OFFSET || motor_id >= (MOTOR_ID_OFFSET + MAX_MOTOR_NUM)) {
        LOG_ERROR("Invalid motor id: %d, should be between %d and %d\r\n", 
                  motor_id, MOTOR_ID_OFFSET, MOTOR_ID_OFFSET + MAX_MOTOR_NUM - 1);
        return status;
    }
    
    // ...existing code...
    uint8_t internal_index = motor_id - MOTOR_ID_OFFSET;
    const MotorStatus_t *read_buffer = DoubleBuffer_GetReadBuffer(&motor_status_dbs[internal_index]);
    if(read_buffer) {
        status = *read_buffer;
    }
    return status;
}

RingBufferStatus_t MotorControl_GetAllStatus(MotorStatus_t status[MAX_MOTOR_NUM])
{
    if(!status) {
        LOG_ERROR("Invalid status buffer\r\n");
        return RING_BUFFER_ERROR;
    }

    RingBufferStatus_t status_code = RING_BUFFER_OK;
    uint32_t current_time = HAL_GetTick();
    
    // ...existing code...
    for(int i = 0; i < MAX_MOTOR_NUM; i++) {		
        const MotorStatus_t *read_buffer = DoubleBuffer_GetReadBuffer(&motor_status_dbs[i]);
        if(!read_buffer) {
            LOG_ERROR("Failed to get read buffer for motor %d (ID: %d)\r\n", i, i + MOTOR_ID_OFFSET);
            return RING_BUFFER_ERROR;
        }
    status[i] = *read_buffer;
        if(status[i].timestamp == 0) {
            LOG_ERROR("Motor %d (ID: %d) status never updated\r\n", i, i + MOTOR_ID_OFFSET);
        } else if(current_time - status[i].timestamp > 2 * 1000) {
            LOG_WARN("Motor %d (ID: %d) status stale: %lu ms\r\n", 
                    i, i + MOTOR_ID_OFFSET, current_time - status[i].timestamp);
        }
    }
    return status_code;
}

RingBufferStatus_t MotorControl_AddCommand(const MotorCmd_t *cmd)
{
    return RingBuffer_Write(&motor_ctrl_cmd_buffer, cmd);
}

static void SendMotorCommand(const MotorCmd_t *cmd)
{
    switch(cmd->mode) {
        case MOTOR_POS_SERVO_MODE:
            for (int i = 0; i < MAX_MOTOR_NUM; i++) {
                const MotorStatus_t *read_buffer = DoubleBuffer_GetReadBuffer(&motor_status_dbs[i]);
                if (!read_buffer) {
                    LOG_ERROR("Failed to get motor status buffer\r\n");
                    return;
                }
                // torqueLimit(i + MOTOR_ID_OFFSET, cmd->torque[i]);
                EnableTorque(i + MOTOR_ID_OFFSET, 1);
                // torqueLimit(i + MOTOR_ID_OFFSET, 600);
            #if USE_SMS_STS_MOTOR
                WritePosEx(i + MOTOR_ID_OFFSET, cmd->target_pos[i], 600, 100);
            #else
                setRunMode(i + MOTOR_ID_OFFSET, POSITION_SERV_MODE); // 设置为位置伺服模式
                WritePos(i + MOTOR_ID_OFFSET, cmd->target_pos[i], 0, 600);
            #endif
                // RegWritePos(cmd->motor_id, cmd->target_pos, 0, 600); // 该方式需配合 RegWriteAction() 使用
                // RegWriteAction();
            }
            /// TODO: 同步写
            break;
        case MOTOR_CONSTANT_SPEED_MODE: 
            break;
        case MOTOR_PWM_SPEED_MODE:
							for (int i = 0; i < MAX_MOTOR_NUM; i++) {
                const MotorStatus_t *read_buffer = DoubleBuffer_GetReadBuffer(&motor_status_dbs[i]);
                if (!read_buffer) {
                    LOG_ERROR("Failed to get motor status buffer\r\n");
                    return;
                }
				        setRunMode(i + MOTOR_ID_OFFSET, PWM_MODE);
                if (cmd->torque[i]) {
                    EnableTorque(i + MOTOR_ID_OFFSET, 1);
                } else {
                    EnableTorque(i + MOTOR_ID_OFFSET, 0);
                }
								WritePWM(i + MOTOR_ID_OFFSET, cmd->torque[i]);

            }
            break;
        case MOTOR_TORQUE_MODE:
            for (int i = 0; i < MAX_MOTOR_NUM; i++) {
                // ...existing code...
                const MotorStatus_t *read_buffer = DoubleBuffer_GetReadBuffer(&motor_status_dbs[i]);
                if (!read_buffer) {
                    LOG_ERROR("Failed to get motor status buffer\r\n");
                    return;
                }
            #if USE_SMS_STS_MOTOR
                // WritePosEx(i + MOTOR_ID_OFFSET, cmd->target_pos[i], 0, 600);
                // WritePosEx(i + MOTOR_ID_OFFSET, read_buffer->position, 600, 50);
                // ...existing code...
                torqueLimit(i + MOTOR_ID_OFFSET, cmd->torque[i]);
                if (cmd->torque[i]) {
                    EnableTorque(i + MOTOR_ID_OFFSET, 1);
                } else {
                    EnableTorque(i + MOTOR_ID_OFFSET, 0);
                }
            #else
                setRunMode(i + MOTOR_ID_OFFSET, CONST_CUR_MODE);
                EnableTorque(i + MOTOR_ID_OFFSET, 0);
                WriteTorque(i + MOTOR_ID_OFFSET, cmd->torque[i]);
                EnableTorque(i + MOTOR_ID_OFFSET, 1);
            #endif
                // ...existing code...
            }
            /// TODO: 同步写
            break;
        default:
            LOG_ERROR("Unsupported motor control mode: %d\r\n", cmd->mode);
            break;
    }
}

void MotorControlLoop(const void *argument)
{
    MotorCmd_t cmd;
    if (RingBuffer_Read(&motor_ctrl_cmd_buffer, &cmd) == RING_BUFFER_OK) {
        SendMotorCommand(&cmd);
    }
    
    // 使用同步读取方式：逐个电机 ReadPos
    ReadMotorStatusSync();
}
