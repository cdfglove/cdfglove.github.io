#include "beep.h"

extern TIM_HandleTypeDef htim1; 

void Beep_Init(void) {

}

void Beep_On(void) {
    // HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET); 
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1); 
void Beep_Off(void) {
    // HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET); 
    HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1); 
}
