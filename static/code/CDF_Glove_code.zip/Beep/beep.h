#ifndef __BEEP_H
#define __BEEP_H

#include <stdint.h>
#include "stm32h7xx_hal.h"

void Beep_Init(void);
void Beep_On(void);
void Beep_Off(void);

#endif // __BEEP_H

