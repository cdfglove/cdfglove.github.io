#include "communication.h"
#include "logger/logger.h"
#include "usart.h"

RingBuffer_t uart1_frame_buffer;
uint8_t uart1_frames[UART1_CMD_BUFFER_SIZE][MODBUS_FRAME_MAX_SIZE];
RingBuffer_t uart2_frame_buffer;
uint8_t uart2_frames[UART2_CMD_BUFFER_SIZE][MODBUS_FRAME_MAX_SIZE];

void Communication_Init(void)
{
    RingBuffer_Init(&uart1_frame_buffer, uart1_frames, UART1_CMD_BUFFER_SIZE, MODBUS_FRAME_MAX_SIZE);
    RingBuffer_Init(&uart2_frame_buffer, uart2_frames, UART2_CMD_BUFFER_SIZE, MODBUS_FRAME_MAX_SIZE);
}

void CommunicationLoop(void const *argument) 
{
    uint32_t length = 0;
    uint8_t cmd[MODBUS_FRAME_MAX_SIZE];

    if(RingBuffer_ReadWithLength(&uart1_frame_buffer, cmd, &length) == RING_BUFFER_OK) {
        Modbus_Process(cmd, length);
    }
}
