#include "Flash.h"
#include "app_type.h"
#include "logger/logger.h"
#include "cmsis_os.h"
#define FLASH_USER_START_ADDR    0x080E0000
#define FLASH_USER_END_ADDR    0x080E0040
/* Base address of the Flash sectors */
#define ADDR_FLASH_SECTOR_0     ((uint32_t)0x08000000) /* 128 Kbytes */
#define ADDR_FLASH_SECTOR_1     ((uint32_t)0x08020000) /* 128 Kbytes */
#define ADDR_FLASH_SECTOR_2     ((uint32_t)0x08040000) /* 128 Kbytes */
#define ADDR_FLASH_SECTOR_3     ((uint32_t)0x08060000) /* 128 Kbytes */
#define ADDR_FLASH_SECTOR_4     ((uint32_t)0x08080000) /* 128 Kbytes */
#define ADDR_FLASH_SECTOR_5     ((uint32_t)0x080A0000) /* 128 Kbytes */
#define ADDR_FLASH_SECTOR_6     ((uint32_t)0x080C0000) /* 128 Kbytes */
#define ADDR_FLASH_SECTOR_7     ((uint32_t)0x080E0000) /* 128 Kbytes */

extern uint32_t mean_value_AD1[ADC1_BUFFER_SIZE] ;
extern uint32_t mean_value_AD2[ADC2_BUFFER_SIZE] ;
extern uint32_t mean_value_AD3[ADC3_BUFFER_SIZE] ;
extern uint32_t mean_motor[MAX_MOTOR_NUM];

/**
   * @brief  select sector
   *      
            uwStartSector = GetSector(FLASH_USER_START_ADDR);
            uwEndSector = GetSector(FLASH_USER_END_ADDR);
   * @param  Address:
   * @retval ?????sector
   */
static uint32_t GetSector(uint32_t Address)
{
   uint32_t sector = 0;

if ((Address < ADDR_FLASH_SECTOR_1) && (Address >= ADDR_FLASH_SECTOR_0)) {
         sector = FLASH_SECTOR_0;
} else if((Address < ADDR_FLASH_SECTOR_2) && (Address >= ADDR_FLASH_SECTOR_1)) {
         sector = FLASH_SECTOR_1;
   } else if ((Address < ADDR_FLASH_SECTOR_3) && (Address >= ADDR_FLASH_SECTOR_2)) {
         sector = FLASH_SECTOR_2;
   } else if ((Address < ADDR_FLASH_SECTOR_4) && (Address >= ADDR_FLASH_SECTOR_3)) {
         sector = FLASH_SECTOR_3;
   } else if ((Address < ADDR_FLASH_SECTOR_5) && (Address >= ADDR_FLASH_SECTOR_4)) {
      sector = FLASH_SECTOR_4;
   } else if ((Address < ADDR_FLASH_SECTOR_6) && (Address >= ADDR_FLASH_SECTOR_5)) {
      sector = FLASH_SECTOR_5;
   } else if ((Address < ADDR_FLASH_SECTOR_7) && (Address >= ADDR_FLASH_SECTOR_6)) {
      sector = FLASH_SECTOR_6;
   } else { /*(Address < FLASH_END_ADDR) && (Address >= ADDR_FLASH_SECTOR_23))*/
      sector = FLASH_SECTOR_7;
   }
   return sector;
}

int FlashWrite()
{
	static uint16_t flash_data[22]={0};
	for(int i=0;i<ADC1_BUFFER_SIZE;i++)
	{
		flash_data[i]=mean_value_AD1[i];
	}
	for(int i=0;i<ADC2_BUFFER_SIZE;i++)
	{
		flash_data[ADC1_BUFFER_SIZE+i]=mean_value_AD2[i];
	}
	for(int i=0;i<ADC3_BUFFER_SIZE;i++)
	{
		flash_data[ADC1_BUFFER_SIZE+ADC2_BUFFER_SIZE+i]=mean_value_AD3[i];
	}
	for(int i=0;i<MAX_MOTOR_NUM;i++)
	{
		flash_data[ADC1_BUFFER_SIZE+ADC2_BUFFER_SIZE+ADC3_BUFFER_SIZE+i]=mean_motor[i];
	}
	 HAL_FLASH_Unlock();
 	 uint32_t FirstSector = 0;
   uint32_t NbOfSectors = 0;
		uint32_t Address = 0;
   FirstSector = GetSector(FLASH_USER_START_ADDR);
   NbOfSectors = GetSector(FLASH_USER_END_ADDR)- FirstSector + 1;
	static FLASH_EraseInitTypeDef EraseInitStruct;
	uint32_t SECTORError = 0;
   /* Fill EraseInit structure*/
   EraseInitStruct.TypeErase     = FLASH_TYPEERASE_SECTORS;
   EraseInitStruct.VoltageRange  = FLASH_VOLTAGE_RANGE_3;/* �ֲ��� */
   EraseInitStruct.Sector        = FirstSector;
   EraseInitStruct.NbSectors     = NbOfSectors;
	osDelay(10);
   if (HAL_FLASHEx_Erase(&EraseInitStruct, &SECTORError) != HAL_OK) {
      return -1;
   }
	 Address = FLASH_USER_START_ADDR;
	 osDelay(1000);
	 for(int i=0;i<5;i++)
	 {
		 osDelay(500);
		  if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_FLASHWORD, Address, flash_data) == HAL_OK) {
						LOG_INFO("Flash Write Successful \r\n");
            break;
      } else {
				if(i==4)
						LOG_ERROR("Flash Write Fail \r\n");
						
      }
	 }
	 osDelay(1000);
	 Address=Address+32;
	 	 for(int i=0;i<5;i++)
	 {
		 osDelay(500);
		  if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_FLASHWORD, Address, &flash_data[16]) == HAL_OK) {
						LOG_INFO("Flash Write Successful \r\n");
            break;
      } else {
				if(i==4)
						LOG_ERROR("Flash Write Fail \r\n");
						
      }
	 }

			HAL_FLASH_Lock();
	 return 1;
}
int FlashRead()
{
	uint32_t Address = 0;
	HAL_FLASH_Unlock();
		
	
	Address = FLASH_USER_START_ADDR;
	
		for(int i=0;i<ADC1_BUFFER_SIZE;i++)
	{
		mean_value_AD1[i]=*(__IO uint16_t*)Address;
		Address = Address + 2;
	}
	
			for(int i=0;i<ADC2_BUFFER_SIZE;i++)
	{
		mean_value_AD2[i]=*(__IO uint16_t*)Address;
		Address = Address + 2;
	}
	
			for(int i=0;i<ADC3_BUFFER_SIZE;i++)
	{
		mean_value_AD3[i]=*(__IO uint16_t*)Address;
		Address = Address + 2;
	}
	
			for(int i=0;i<MAX_MOTOR_NUM;i++)
	{
		mean_motor[i]=*(__IO uint16_t*)Address;
		Address = Address + 2;
	}
	HAL_FLASH_Lock();

		 
}