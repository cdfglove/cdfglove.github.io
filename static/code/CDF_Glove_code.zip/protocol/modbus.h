#ifndef __MODBUS_H
#define __MODBUS_H

#include <stdint.h>
#include <stdbool.h>

#define USE_STANDARD_MODBUS_PROTOCOL 1

#define MODBUS_SLAVE_ADDRESS 0x01
#define MODBUS_SLAVE_ADDRESS 0x01
#define MODBUS_BAUDRATE      500000
#define MODBUS_RX_BUFFER_SIZE 8
#define MODBUS_TX_BUFFER_SIZE 256

#if USE_STANDARD_MODBUS_PROTOCOL
#define MODBUS_RESP_DATA_OFFSET 3
#else
#define MODBUS_RESP_DATA_OFFSET 4
#endif

#define RS485_DE_RE_GPIO_PORT GPIOB
#define RS485_DE_RE_GPIO_PORT GPIOB
#define RS485_DE_RE_PIN       GPIO_PIN_1

#define MODBUS_READ_HOLDING_REGISTERS 0x03
#define MODBUS_READ_HOLDING_REGISTERS 0x03
#define MODBUS_WRITE_SINGLE_REGISTER  0x06
#define MODBUS_WRITE_MULTIPLE_REGISTERS 0x10

#define MODBUS_REG_ADDRESS_POS              0x01
#define MODBUS_REG_ADDRESS_POS              0x01
#define MODBUS_REG_ADDRESS_TARGET_POS       0x02
#define MODBUS_REG_ADDRESS_SPEED            0x03
#define MODBUS_REG_ADDRESS_TARGET_SPEED     0x04
#define MODBUS_REG_ADDRESS_TORQUE           0x05
#define MODBUS_REG_ADDRESS_LOAD             0x06

#define MODBUS_REG_ADDRESS_BEEP             0x10
#define MODBUS_REG_ADDRESS_CALIBRATE        0x20

#define MODBUS_REG_ADDRESS_TARGET_THUMB_TORQUE     0x40
#define MODBUS_REG_ADDRESS_TARGET_INDEX_TORQUE     0x41
#define MODBUS_REG_ADDRESS_TARGET_MIDDLE_TORQUE    0x42
#define MODBUS_REG_ADDRESS_TARGET_RING_TORQUE      0x43
#define MODBUS_REG_ADDRESS_TARGET_PINKY_TORQUE     0x44
#define MODBUS_REG_ADDRESS_TARGET_TORQUE           0x45
#define MODEBUS_REG_ADDRESS_LOW_DOF                0x80
#define MODEBUS_REG_ADDRESS_READCALIBRATIONSTATUS  0xC0
#define MODEBUS_REG_ADDRESS_READCALIBRATION        0xC1
#define MODEBUS_REG_ADDRESS_LINEAR_CONCTROL        0xB0

#define MODBUS_ERROR_NONE        0
#define MODBUS_ERROR_NONE        0
#define MODBUS_ERROR_CRC         1
#define MODBUS_ERROR_ADDRESS     2
#define MODBUS_ERROR_FUNCTION    3

#define MODBUS_HOLDING_REGISTERS_SIZE 100
#define MODBUS_HOLDING_REGISTERS_SIZE 100

#define MODBUS_FRAME_MAX_SIZE 256
#define UART4_FRAME_BUFFER_SIZE 8
typedef struct {
    uint16_t length;
    uint8_t data[MODBUS_FRAME_MAX_SIZE];
} ModbusFrame_t;

bool Modbus_Process(uint8_t *request, uint32_t length);
bool Modbus_Process(uint8_t *request, uint32_t length);

void Modbus_SetHoldingRegister(uint16_t address, uint16_t value);
uint16_t Modbus_GetHoldingRegister(uint16_t address);
void Modbus_SendDatas(uint8_t *data, uint32_t len);
uint16_t CRC16_test(uint8_t *data, uint16_t length);

#endif // __MODBUS_H
