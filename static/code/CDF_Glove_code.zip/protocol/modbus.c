#include "modbus.h"
#include "logger/logger.h"
#include "motor/motor.h"
#include "Beep/beep.h"
#include "app_type.h"
#include "bsp_ics6b11.h"
#include "usart.h"

#include <string.h>

extern volatile uint16_t AD1_value[ADC1_BUFFER_SIZE];
extern volatile uint16_t AD2_value[ADC2_BUFFER_SIZE];
extern volatile uint16_t AD3_value[ADC3_BUFFER_SIZE];
#define offset 500

// ...existing code...
extern uint32_t mean_value_AD1[ADC1_BUFFER_SIZE];
extern uint32_t mean_value_AD2[ADC2_BUFFER_SIZE];
extern uint32_t mean_value_AD3[ADC3_BUFFER_SIZE];
extern uint32_t mean_motor[MAX_MOTOR_NUM];
extern uint8_t Flag_Calibration;		
extern uint8_t Triger_Calibration_Start;
extern uint8_t Triger_Calibration_End;
//0826 calibration

uint8_t last_positions[MODBUS_TX_BUFFER_SIZE] = {0};
uint8_t last_velocities[MODBUS_TX_BUFFER_SIZE] = {0};
uint8_t last_torques[MODBUS_TX_BUFFER_SIZE] = {0};
uint8_t last_loades[MODBUS_TX_BUFFER_SIZE] = {0};
uint8_t last_dof_hand[MODBUS_TX_BUFFER_SIZE] = {0};

static uint16_t holdingRegisters[MODBUS_HOLDING_REGISTERS_SIZE];

// ...existing code...
static uint32_t last_force_refresh_time = 0;
#define FORCE_REFRESH_MIN_INTERVAL_MS 50

void Modbus_SendData(uint8_t *data, uint32_t len);

// ...existing code...
static uint16_t ModbusCRC16(uint8_t *data, uint16_t length) 
{
  uint16_t crc = 0xFFFF;
  for (uint16_t pos = 0; pos < length; pos++) 
  {
    crc ^= (uint16_t)data[pos];
    for (uint8_t i = 8; i != 0; i--) 
    {
      if ((crc & 0x0001) != 0) 
      {
        crc >>= 1;
        crc ^= 0xA001;
      } 
      else 
      {
        crc >>= 1;
      }
    }
  }
  return crc;
}

uint16_t CRC16_test(uint8_t *data, uint16_t length)
{
    return ModbusCRC16(data, length);
}

// ...existing code...
static void Modbus_ReadHoldingRegisters(uint16_t startAddress, uint16_t numRegisters) 
{
    uint32_t data_len = 0;
    uint8_t response[MODBUS_TX_BUFFER_SIZE];

    response[0] = MODBUS_SLAVE_ADDRESS;
    response[1] = MODBUS_READ_HOLDING_REGISTERS;

    // ...existing code...
    /*
    if (startAddress == MODBUS_REG_ADDRESS_POS ||
        startAddress == MODBUS_REG_ADDRESS_SPEED ||
        startAddress == MODBUS_REG_ADDRESS_TORQUE ||
        startAddress == MODBUS_REG_ADDRESS_LOAD ||
        startAddress == MODEBUS_REG_ADDRESS_LOW_DOF) {
        
        uint32_t current_time = HAL_GetTick();
        if (current_time - last_force_refresh_time >= FORCE_REFRESH_MIN_INTERVAL_MS) {
            MotorControl_ForceRefreshPositions();
            last_force_refresh_time = current_time;
        }
    }
    */

    if (startAddress == MODBUS_REG_ADDRESS_POS) {
        MotorStatus_t status[MAX_MOTOR_NUM];
        if (MotorControl_GetAllStatus(status) == RING_BUFFER_OK) {
            // ...existing code...
            if (status[0].position == 0) {
                LOG_ERROR("Motor 1 position is zero.\r\n");
            }
						
						//0826  calibraiton
            response[MODBUS_RESP_DATA_OFFSET + data_len] = (status[0].position-(uint16_t)(mean_motor[0] & 0xFFFF)+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 1] = (status[0].position-(uint16_t)(mean_motor[0] & 0xFFFF)+offset) & 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 2] = (AD2_value[4] - (uint16_t)(mean_value_AD2[4] & 0xFFFF)+offset)>> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 3] = (AD2_value[4] - (uint16_t)(mean_value_AD2[4] & 0xFFFF)+offset)& 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 4] = ((uint16_t)(mean_value_AD2[3] & 0xFFFF)-AD2_value[3]+offset)>> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 5] = ((uint16_t)(mean_value_AD2[3] & 0xFFFF)-AD2_value[3]+offset)& 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 6] = (AD1_value[4] - (uint16_t)(mean_value_AD1[4] & 0xFFFF)+offset)>> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 7] = (AD1_value[4] - (uint16_t)(mean_value_AD1[4] & 0xFFFF)+offset)& 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 8] = (AD1_value[3] - (uint16_t)(mean_value_AD1[3] & 0xFFFF)+offset)>> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 9] = (AD1_value[3] - (uint16_t)(mean_value_AD1[3] & 0xFFFF)+offset)& 0xFF; // 低字节
            data_len += 10;
            // ...existing code...
            if (status[1].position == 0) {
                LOG_ERROR("Motor 2 position is zero.\r\n");
            }
            response[MODBUS_RESP_DATA_OFFSET + data_len] = (status[1].position-(uint16_t)(mean_motor[1] & 0xFFFF)+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 1] = (status[1].position-(uint16_t)(mean_motor[1] & 0xFFFF)+offset) & 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 2] = (AD2_value[2] - (uint16_t)(mean_value_AD2[2] & 0xFFFF)+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 3] = (AD2_value[2] - (uint16_t)(mean_value_AD2[2] & 0xFFFF)+offset) & 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 4] = ((uint16_t)(mean_value_AD2[1] & 0xFFFF)-AD2_value[1]+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 5] = ((uint16_t)(mean_value_AD2[1] & 0xFFFF)-AD2_value[1]+offset) & 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 6] = (AD2_value[0] - (uint16_t)(mean_value_AD2[0] & 0xFFFF)+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 7] = (AD2_value[0] - (uint16_t)(mean_value_AD2[0] & 0xFFFF)+offset) & 0xFF; // 低字节
            data_len += 8;
            // ...existing code...
            if (status[2].position == 0) {
                LOG_ERROR("Motor 3 position is zero.\r\n");
            }
            response[MODBUS_RESP_DATA_OFFSET + data_len] = (status[2].position-(uint16_t)(mean_motor[2] & 0xFFFF)+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 1] = (status[2].position-(uint16_t)(mean_motor[2] & 0xFFFF)+offset) & 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 2] = (AD1_value[1] - (uint16_t)(mean_value_AD1[1] & 0xFFFF)+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 3] = (AD1_value[1] - (uint16_t)(mean_value_AD1[1] & 0xFFFF)+offset)& 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 4] = ((uint16_t)(mean_value_AD1[0] & 0xFFFF)-AD1_value[0]+offset)>> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 5] = ((uint16_t)(mean_value_AD1[0] & 0xFFFF)-AD1_value[0]+offset)& 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 6] = (AD3_value[0] - (uint16_t)(mean_value_AD3[0] & 0xFFFF)+offset)>> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 7] = (AD3_value[0] - (uint16_t)(mean_value_AD3[0] & 0xFFFF)+offset)& 0xFF; // 低字节
            data_len += 8;
            // ...existing code...
            if (status[3].position == 0) {
                LOG_ERROR("Motor 4 position is zero.\r\n");
            }
            response[MODBUS_RESP_DATA_OFFSET + data_len] = (status[3].position-(uint16_t)(mean_motor[3] & 0xFFFF)+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 1] = (status[3].position-(uint16_t)(mean_motor[3] & 0xFFFF)+offset) & 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 2] = (AD1_value[2] - (uint16_t)(mean_value_AD1[2] & 0xFFFF)+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 3] = (AD1_value[2] - (uint16_t)(mean_value_AD1[2] & 0xFFFF)+offset) & 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 4] = ((uint16_t)(mean_value_AD3[5] & 0xFFFF)-AD3_value[5]+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 5] = ((uint16_t)(mean_value_AD3[5] & 0xFFFF)-AD3_value[5]+offset) & 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 6] = (AD3_value[4] - (uint16_t)(mean_value_AD3[4] & 0xFFFF)+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 7] = (AD3_value[4] - (uint16_t)(mean_value_AD3[4] & 0xFFFF)+offset) & 0xFF; // 低字节
            data_len += 8;
            // ...existing code...
            if (status[4].position == 0) {
                LOG_ERROR("Motor 5 position is zero.\r\n");
            }
            response[MODBUS_RESP_DATA_OFFSET + data_len] = (status[4].position-(uint16_t)(mean_motor[4] & 0xFFFF)+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 1] = (status[4].position-(uint16_t)(mean_motor[4] & 0xFFFF)+offset)& 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 2] = (AD3_value[3] - (uint16_t)(mean_value_AD3[3] & 0xFFFF)+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 3] = (AD3_value[3] - (uint16_t)(mean_value_AD3[3] & 0xFFFF)+offset) & 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 4] = ((uint16_t)(mean_value_AD3[2] & 0xFFFF)-AD3_value[2]+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 5] = ((uint16_t)(mean_value_AD3[2] & 0xFFFF)-AD3_value[2]+offset) & 0xFF; // 低字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 6] = (AD3_value[1] - (uint16_t)(mean_value_AD3[1] & 0xFFFF)+offset) >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 7] = (AD3_value[1] - (uint16_t)(mean_value_AD3[1] & 0xFFFF)+offset) & 0xFF; // 低字节
            data_len += 8;
						//0826  calibraiton
            memcpy(last_positions, response + MODBUS_RESP_DATA_OFFSET, data_len);
        } else {
            LOG_WARN("Modbus_ReadHoldingRegisters: MotorControl_GetAllStatus failed, use last_positions\r\n");
            data_len = 42;
            memcpy(response + MODBUS_RESP_DATA_OFFSET, last_positions, data_len);
        }
    }
    else if (startAddress == MODBUS_REG_ADDRESS_SPEED) {
        MotorStatus_t status[MAX_MOTOR_NUM];
        if (MotorControl_GetAllStatus(status) == RING_BUFFER_OK) {
            for (int i = 0; i < MAX_MOTOR_NUM; i++) {
                response[MODBUS_RESP_DATA_OFFSET + data_len] = status[i].speed >> 8; // 高字节
                response[MODBUS_RESP_DATA_OFFSET + data_len + 1] = status[i].speed & 0xFF; // 低字节
                data_len += 2; 
            }
            memcpy(last_velocities, response + MODBUS_RESP_DATA_OFFSET, data_len);
        } else {
            data_len = 10;
            memcpy(response + MODBUS_RESP_DATA_OFFSET, last_velocities, data_len);
        }
    }
    else if (startAddress == MODBUS_REG_ADDRESS_TORQUE) {
        MotorStatus_t status[MAX_MOTOR_NUM];
        if (MotorControl_GetAllStatus(status) == RING_BUFFER_OK) {
            for (int i = 0; i < MAX_MOTOR_NUM; i++) {
                response[MODBUS_RESP_DATA_OFFSET + data_len] = status[i].current >> 8; // 高字节
                response[MODBUS_RESP_DATA_OFFSET + data_len + 1] = status[i].current & 0xFF; // 低字节 
                data_len += 2;
            }
            memcpy(last_torques, response + MODBUS_RESP_DATA_OFFSET, data_len);
        } else {
            data_len = 10;
            memcpy(response + MODBUS_RESP_DATA_OFFSET, last_torques, data_len); 
        }
    }
    else if (startAddress == MODBUS_REG_ADDRESS_LOAD) {
        MotorStatus_t status[MAX_MOTOR_NUM];
        if (MotorControl_GetAllStatus(status) == RING_BUFFER_OK) {
            for (int i = 0; i < MAX_MOTOR_NUM; i++) {
                response[MODBUS_RESP_DATA_OFFSET + data_len] = status[i].load >> 8; // 高字节
                response[MODBUS_RESP_DATA_OFFSET + data_len + 1] = status[i].load & 0xFF; // 低字节 
                data_len += 2;
            }
            memcpy(last_loades, response + MODBUS_RESP_DATA_OFFSET, data_len);
        } else {
            data_len = 10;
            memcpy(response + MODBUS_RESP_DATA_OFFSET, last_loades, data_len); 
        }
    } else if (startAddress == MODEBUS_REG_ADDRESS_LOW_DOF) {
        MotorStatus_t status[MAX_MOTOR_NUM];
        if (MotorControl_GetAllStatus(status) == RING_BUFFER_OK) {
            for (int i = 0; i < MAX_MOTOR_NUM; i++) {
                response[MODBUS_RESP_DATA_OFFSET + data_len] = status[i].position >> 8; // 高字节
                response[MODBUS_RESP_DATA_OFFSET + data_len + 1] = status[i].position & 0xFF; // 低字节
                response[MODBUS_RESP_DATA_OFFSET + data_len + 2] = status[i].load >> 8; // 高字节
                response[MODBUS_RESP_DATA_OFFSET + data_len + 3] = status[i].load & 0xFF; // 低字节
                data_len += 4;  
            }
            response[MODBUS_RESP_DATA_OFFSET + data_len] = AD1_value[4] >> 8; // 高字节
            response[MODBUS_RESP_DATA_OFFSET + data_len + 1] = AD1_value[4] & 0xFF; // 高字节
            data_len += 2;
            memcpy(last_dof_hand, response + MODBUS_RESP_DATA_OFFSET, data_len);
        } else {
            data_len = 22;
            memcpy(response + MODBUS_RESP_DATA_OFFSET, last_dof_hand, data_len);
        }
    } else return;

#if USE_STANDARD_MODBUS_PROTOCOL
    response[2] = data_len; // 字节数. 标准 Modbus 协议规定
#else
    response[2] = data_len & 0xFF; // 字节数
    response[3] = (data_len >> 8) & 0xFF;
#endif
    uint16_t crc = ModbusCRC16(response, MODBUS_RESP_DATA_OFFSET + data_len);
    response[MODBUS_RESP_DATA_OFFSET + data_len] = crc & 0xFF;
    response[MODBUS_RESP_DATA_OFFSET + data_len + 1] = (crc >> 8) & 0xFF;

    Modbus_SendData(response, MODBUS_RESP_DATA_OFFSET + 2 + data_len);
}

// ...existing code...
static void Modbus_WriteSingleRegister(uint16_t startAddress, uint16_t value) 
{
    uint8_t response[8];
    response[0] = MODBUS_SLAVE_ADDRESS;
    response[1] = MODBUS_WRITE_SINGLE_REGISTER;
    response[2] = startAddress >> 8;
    response[3] = startAddress & 0xFF;
    response[4] = value >> 8;
    response[5] = value & 0xFF;

    uint16_t crc = ModbusCRC16(response, 6);
    response[6] = crc & 0xFF;
    response[7] = (crc >> 8) & 0xFF;

    if (startAddress == MODBUS_REG_ADDRESS_BEEP) {
    // ...existing code...
        if (value == 0) {
            Beep_Off(); 
        } else {
            Beep_On();
        }
    }		else if(startAddress == MODBUS_REG_ADDRESS_CALIBRATE)
		{
			Flag_Calibration=1;
			Triger_Calibration_Start=1;
		}

    Modbus_SendData(response, 8);
}

static void Modbus_WriteMultipleRegisters(uint16_t startAddress, uint16_t numRegisters, uint8_t *data, uint16_t dataLength)
{
    uint8_t response[8];
    response[0] = MODBUS_SLAVE_ADDRESS;
    response[1] = MODBUS_WRITE_MULTIPLE_REGISTERS;
    response[2] = startAddress >> 8;
    response[3] = startAddress & 0xFF;
    response[4] = numRegisters >> 8;
    response[5] = numRegisters & 0xFF;
    
    uint16_t crc = ModbusCRC16(response, 6);
    response[6] = crc & 0xFF;
    response[7] = (crc >> 8) & 0xFF;

    // ...existing code...
    if (startAddress == MODBUS_REG_ADDRESS_TARGET_POS) {
        MotorCmd_t cmd = {0};
        cmd.mode = MOTOR_POS_SERVO_MODE;
        cmd.torque_enable = 1;
        
        if (dataLength != numRegisters * 2) {
            LOG_ERROR("Modbus_WriteMultipleRegisters: dataLength(%d) != numRegisters(%d) * 2\r\n", dataLength, numRegisters);
            return;
        }
        for (int i = 0; i < MAX_MOTOR_NUM; i++) {
            cmd.target_pos[i] = (data[i * 2] << 8) | data[i * 2 + 1];
        }
        MotorControl_AddCommand(&cmd);
    } else if (startAddress == MODBUS_REG_ADDRESS_TARGET_SPEED) {
      
    } else if (startAddress == MODBUS_REG_ADDRESS_TARGET_TORQUE) {
        MotorCmd_t cmd = {0};
        cmd.mode = MOTOR_PWM_SPEED_MODE;
        cmd.torque_enable = 1;
        
    // ...existing code...
        if (dataLength != numRegisters * 2 || numRegisters != 2 * MAX_MOTOR_NUM ) {
            LOG_ERROR("Modbus_WriteMultipleRegisters: dataLength(%d) != numRegisters(%d) * 2\r\n", dataLength, numRegisters);
            return;
        }
    // ...existing code...
        for (int i = 0; i < MAX_MOTOR_NUM; i++) {
            cmd.torque[i] = (data[i * 4] << 8) | data[i * 4 + 1]; // 转换为实际力矩值 

        }
        MotorControl_AddCommand(&cmd);
    } else if (startAddress == MODBUS_REG_ADDRESS_TARGET_THUMB_TORQUE) {
      
    } else if (startAddress == MODBUS_REG_ADDRESS_TARGET_INDEX_TORQUE) {
      
    } else if (startAddress == MODBUS_REG_ADDRESS_TARGET_MIDDLE_TORQUE) {

    } else if (startAddress == MODBUS_REG_ADDRESS_TARGET_RING_TORQUE) {
   
    } else if (startAddress == MODBUS_REG_ADDRESS_TARGET_PINKY_TORQUE) {

    } else {
    // ...existing code...
    }
    // ...existing code...
		if (startAddress == MODEBUS_REG_ADDRESS_LINEAR_CONCTROL) {
				for (int i = 0; i < LINEAR_MAX_NUM; i++) {
						linearMotoPlay[i].mode = data[i * 2];
						linearMotoPlay[i].gain = data[1 + i * 2];
				}
		}
    Modbus_SendData(response, 8); //待确认
}

// 添加ASCII十六进制字符串转换函数
static uint8_t hex_char_to_byte(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return 0;
}

static bool convert_ascii_to_binary(uint8_t *ascii_data, uint32_t ascii_len, uint8_t *binary_data, uint32_t *binary_len) {
    if (ascii_len % 2 != 0) return false; // ASCII长度必须是偶数
    
    *binary_len = ascii_len / 2;
    for (uint32_t i = 0; i < *binary_len; i++) {
        binary_data[i] = (hex_char_to_byte(ascii_data[i*2]) << 4) | hex_char_to_byte(ascii_data[i*2+1]);
    }
    return true;
}

// Modbus 处理请求
bool Modbus_Process(uint8_t *request, uint32_t length) 
{	
    // ...existing code...
    uint8_t binary_buffer[128];
    uint8_t *process_data = request;
    uint32_t process_length = length;
    
    // ...existing code...
    
    if (process_length < 6) 
    {
        LOG_ERROR("Modbus_Process: length < 6\r\n");
    return false;
    }

    uint16_t crc = ModbusCRC16(process_data, process_length - 2);
    uint16_t receivedCrc = (process_data[process_length - 1] << 8) | process_data[process_length - 2];
    if (crc != receivedCrc) return false;

    uint8_t slaveAddress = process_data[0];
    if (slaveAddress != MODBUS_SLAVE_ADDRESS) 
    {
        LOG_ERROR("Modbus_Process: slaveAddress(%#x)!= MODBUS_SLAVE_ADDRESS(%#x)\r\n", slaveAddress, MODBUS_SLAVE_ADDRESS);
    return false;
    }

    uint8_t functionCode = process_data[1];
    uint16_t startAddress = (process_data[2] << 8) | process_data[3];
    uint16_t numRegisters = (process_data[4] << 8) | process_data[5];

    switch (functionCode) 
    {
        case MODBUS_READ_HOLDING_REGISTERS:
            Modbus_ReadHoldingRegisters(startAddress, numRegisters);
            break;
        case MODBUS_WRITE_SINGLE_REGISTER:
            Modbus_WriteSingleRegister(startAddress, (process_data[4] << 8) | process_data[5]);
            break;
        case MODBUS_WRITE_MULTIPLE_REGISTERS:
            Modbus_WriteMultipleRegisters(startAddress, numRegisters, process_data + 7, process_length - 9);
            break;
        default:
            // ...existing code...
            break;
    }
    return true;
}

// 设置保持寄存器
void Modbus_SetHoldingRegister(uint16_t address, uint16_t value) 
{
    if (address < MODBUS_HOLDING_REGISTERS_SIZE) 
    {
        holdingRegisters[address] = value;
    }
}

// 获取保持寄存器
uint16_t Modbus_GetHoldingRegister(uint16_t address) 
{
    if (address < MODBUS_HOLDING_REGISTERS_SIZE) 
    {
        return holdingRegisters[address];
    }
    return 0;
}

void Modbus_SendDatas(uint8_t *data, uint32_t len)
{
    uint8_t response[6 + len];
    response[0] = MODBUS_SLAVE_ADDRESS;
    response[1] = MODBUS_READ_HOLDING_REGISTERS;
    uint32_t nums = len * 2;
    response[2] = nums; // 字节数

    for (uint16_t i = 0; i < len; i++) 
    {
        response[MODBUS_RESP_DATA_OFFSET + i] = data[i];
    }

    uint16_t crc = ModbusCRC16(response, MODBUS_RESP_DATA_OFFSET + len);
    response[MODBUS_RESP_DATA_OFFSET + len] = crc & 0xFF;
    response[MODBUS_RESP_DATA_OFFSET + len + 1] = (crc >> 8) & 0xFF;

    Modbus_SendData(response, MODBUS_RESP_DATA_OFFSET + 2 + len * 2);
}
