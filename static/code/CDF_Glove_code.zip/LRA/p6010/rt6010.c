#include "rt6010.h"

void RT6010_Init(uint8_t addr) 
{
    uint8_t init_sequence[] = {
        0x02, 0x01,
        0x07, 0x06,
        0x10, 0x01,
        0x12, 0x01
    };

    for (int i = 0; i < sizeof(init_sequence); i += 2) {
        HAL_I2C_Mem_Write(&hi2c1, addr, init_sequence[i], I2C_MEMADD_SIZE_8BIT, 
                          &init_sequence[i + 1], sizeof(init_sequence[i + 1]), 1000);
    }        
}

void RT6010_WriteWaveForm(uint8_t addr, uint8_t waveform_number, const uint8_t *waveform_data, uint16_t size)

{
    uint8_t clr_wave_data = 0x06;
    HAL_I2C_Mem_Write(&hi2c1, addr, 0x07, I2C_MEMADD_SIZE_8BIT, &clr_wave_data, sizeof(clr_wave_data), 1000);

    uint8_t sram_addr_l = 0x00;
    uint8_t sram_addr_h = 0x02;
    HAL_I2C_Mem_Write(&hi2c1, addr, 0x08, I2C_MEMADD_SIZE_8BIT, &sram_addr_l, sizeof(sram_addr_l), 1000);
    HAL_I2C_Mem_Write(&hi2c1, addr, 0x09, I2C_MEMADD_SIZE_8BIT, &sram_addr_h, sizeof(sram_addr_h), 1000);
    for (uint16_t i = 0; i < size; i++) {
        HAL_I2C_Mem_Write(&hi2c1, addr, 0x0A, I2C_MEMADD_SIZE_8BIT, &waveform_data[i], sizeof(waveform_data[i]), 1000);
    }

    uint8_t waveform_table[4] = {
        sram_addr_l, sram_addr_h,
        size & 0xFF, size >> 8
    };
    HAL_I2C_Mem_Write(&hi2c1, addr, 0x02, I2C_MEMADD_SIZE_8BIT, waveform_table, sizeof(waveform_table), 1000);
}

void RT6010_WriteWaveformToSRAM(uint8_t addr, uint8_t* waveform_data, uint16_t waveform_size, uint8_t* playlist_data, uint16_t playlist_size) {
    uint8_t clr_sram = 0x06;
    HAL_I2C_Mem_Write(&hi2c1, addr, 0x07, I2C_MEMADD_SIZE_8BIT, &clr_sram, sizeof(clr_sram), 1000);

    for (uint16_t i = 0; i < waveform_size; i++) {
        HAL_I2C_Mem_Write(&hi2c1, addr, 0x0A, I2C_MEMADD_SIZE_8BIT, &waveform_data[i], sizeof(waveform_data[i]), 1000);
    }

    for (uint16_t i = 0; i < playlist_size; i++) {
        HAL_I2C_Mem_Write(&hi2c1, addr, 0x0A, I2C_MEMADD_SIZE_8BIT, &playlist_data[i], sizeof(playlist_data[i]), 1000);
    }
}

void RT6010_PlayWaveForm(uint8_t addr, uint8_t waveform_number)
{
    uint8_t data = waveform_number;
    HAL_I2C_Mem_Write(&hi2c1, addr, 0x13, I2C_MEMADD_SIZE_8BIT, &data, sizeof(data), 1000);
}

void RT6010_PlayRAM(uint8_t addr) 
{
    uint8_t play_mode = 0x01;
    HAL_I2C_Mem_Write(&hi2c1, addr, 0x11, I2C_MEMADD_SIZE_8BIT, &play_mode, sizeof(play_mode), 1000);

    uint8_t go = 0x01;
    HAL_I2C_Mem_Write(&hi2c1, addr, 0x12, I2C_MEMADD_SIZE_8BIT, &go, sizeof(go), 1000);
}

void RT6010_Stop(uint8_t addr)
{
    uint8_t data = 0x00;
    HAL_I2C_Mem_Write(&hi2c1, addr, 0x12, I2C_MEMADD_SIZE_8BIT, &data, sizeof(data), 1000);
}