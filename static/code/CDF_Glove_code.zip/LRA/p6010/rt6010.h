#ifndef __RT6010_H
#define __RT6010_H

#include <stdint.h>
#include "i2c.h"
#include "stm32h7xx_hal.h"

#define RT6010_I2C_ADDR_1 0x5E
#define RT6010_I2C_ADDR_2 0x5F

// for test
#define WAVEFORM_SIZE 128 

#endif // __RT6010_H