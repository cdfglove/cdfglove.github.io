#ifndef __LOGGER_H
#define __LOGGER_H

#include <stdio.h>
#include "stm32h7xx_hal.h"

typedef enum {
  LOG_LEVEL_DEBUG = 0,
  LOG_LEVEL_INFO,
  LOG_LEVEL_WARN,
  LOG_LEVEL_ERROR,
  LOG_LEVEL_NONE 
} LogLevel;

extern LogLevel global_log_level;

#define LOG(level, format, ...) \
  do { \
    if (level >= global_log_level) { \
      printf("[%s] %s:%d: " format "\r\n", \
              log_level_strings[level], __func__, __LINE__, ##__VA_ARGS__); \
  } \
  } while (0)

#define LOG_DEBUG(format, ...) LOG(LOG_LEVEL_DEBUG, format, ##__VA_ARGS__)
#define LOG_INFO(format, ...)  LOG(LOG_LEVEL_INFO,  format, ##__VA_ARGS__)
#define LOG_WARN(format, ...)  LOG(LOG_LEVEL_WARN,  format, ##__VA_ARGS__)
#define LOG_ERROR(format, ...) LOG(LOG_LEVEL_ERROR, format, ##__VA_ARGS__)

extern const char* log_level_strings[];

void SetLogLevel(LogLevel level);

#endif // __LOGGER_H
