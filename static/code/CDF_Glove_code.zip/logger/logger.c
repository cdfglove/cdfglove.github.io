#include "logger.h"
#include "usart.h"
#include "cmsis_os.h"

LogLevel global_log_level = LOG_LEVEL_INFO; 

const char* log_level_strings[] = {
  "DEBUG",
  "INFO",
  "WARN",
  "ERROR"
};

extern UART_HandleTypeDef huart1;
extern osMutexId uart1_mutex; 

int fputc(int ch, FILE *f)
{
  if (uart1_mutex == NULL) {
    if (HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 10) != HAL_OK) {
      return -1;
    }
    return ch;
  }
  
  if (osMutexWait(uart1_mutex, 10) == osOK) {
    HAL_StatusTypeDef status = HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 10);
    osMutexRelease(uart1_mutex);
    return (status == HAL_OK) ? ch : -1;
  } else {
    return -1;
  }
}

int fgetc(FILE *f)
{
  uint8_t ch = 0;
  HAL_UART_Receive(&huart1, &ch, 1, 0xffff);
  return ch;
}

void SetLogLevel(LogLevel level) {
  global_log_level = level;
}
